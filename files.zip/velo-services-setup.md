# VELO — COMPLETE SERVICE SETUP GUIDE
## Every account, every key, every env var — step by step

---

## WHAT THIS DOCUMENT IS

The backend prompt tells Claude Code *what* to build.
This document tells *you* how to get every API key and connection string it needs.

Do this BEFORE running Claude Code. It takes about 90 minutes total.
Each section tells you: which website → what to click → what to copy → where to paste it.

---

## THE COMPLETE `.env` FILE

Create this file at `velo-backend/.env` and fill it in as you go through each section below.

```dotenv
# ─────────────────────────────────────────────
# VELO BACKEND — ENVIRONMENT VARIABLES
# Fill each value by following the setup guide
# NEVER commit this file to git
# ─────────────────────────────────────────────

# ── APP ──────────────────────────────────────
NODE_ENV=development
PORT=3000
API_VERSION=v1
FRONTEND_URL=http://localhost:4200
ALLOWED_ORIGINS=http://localhost:4200,http://localhost:3000

# ── JWT ──────────────────────────────────────
# Generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_ACCESS_SECRET=PASTE_64_BYTE_HEX_HERE
JWT_REFRESH_SECRET=PASTE_DIFFERENT_64_BYTE_HEX_HERE
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=30d

# ── MONGODB ATLAS ─────────────────────────────
# Section 1 below — copy from Atlas dashboard
MONGODB_URI=mongodb+srv://velo_user:PASSWORD@cluster0.XXXXX.mongodb.net/velo_production?retryWrites=true&w=majority
MONGODB_DB_NAME=velo_production

# ── UPSTASH REDIS ─────────────────────────────
# Section 2 below — copy from Upstash console
UPSTASH_REDIS_REST_URL=https://YOUR-INSTANCE.upstash.io
UPSTASH_REDIS_REST_TOKEN=YOUR_UPSTASH_TOKEN

# ── ANTHROPIC (Claude AI) ─────────────────────
# Section 3 below — copy from console.anthropic.com
ANTHROPIC_API_KEY=sk-ant-XXXXXXXXXXXXX

# ── GOOGLE GEMINI ─────────────────────────────
# Section 4 below — copy from aistudio.google.com
GEMINI_API_KEY=AIzaSyXXXXXXXXXXXXXXXXXXX

# ── FIREBASE (Push notifications) ─────────────
# Section 5 below — copy from Firebase console
FIREBASE_PROJECT_ID=velo-app-XXXXX
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nXXXXXXXX\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-XXXXX@velo-app-XXXXX.iam.gserviceaccount.com

# ── RESEND (Transactional email) ──────────────
# Section 6 below — copy from resend.com
RESEND_API_KEY=re_XXXXXXXXXXXX
RESEND_FROM_EMAIL=noreply@yourdomain.com
RESEND_FROM_NAME=Velo

# ── GOOGLE OAUTH (Section 7 — add in Phase 2) ─
GOOGLE_CLIENT_ID=XXXXX.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-XXXXXXXX

# ── RATE LIMITING ─────────────────────────────
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
AUTH_RATE_LIMIT_MAX=10

# ── LOGGING ───────────────────────────────────
LOG_LEVEL=debug
LOG_FORMAT=json
```

---

## SECTION 1 — MONGODB ATLAS

**Time: 15 minutes**

### Step 1 — Create account

Go to: https://cloud.mongodb.com

Click **Try Free** → sign up with Google or email → verify email.

No credit card required for M0 free tier.

### Step 2 — Create a project

After login you see "Create a project."

- Project Name: `Velo`
- Click **Next** → **Create Project**

### Step 3 — Build a cluster (the database server)

Click **Build a Database**.

Choose **M0 Free** (it says "Free forever" — pick this one, not M2 or M5).

- Provider: **AWS**
- Region: Pick the closest to you. UK → `eu-west-2 (London)`. India → `ap-south-1 (Mumbai)`.
- Cluster Name: `Cluster0` (leave default)

Click **Create Deployment**.

### Step 4 — Create a database user

A popup appears: "How would you like to authenticate?"

Choose **Username and Password**.

- Username: `velo_user`
- Password: click **Autogenerate Secure Password** → copy the password somewhere safe

Click **Create Database User**.

Click **Choose a connection method** at the bottom.

### Step 5 — Allow network access

Click **Network Access** in the left sidebar → **Add IP Address**.

For development: click **Allow Access from Anywhere** (adds `0.0.0.0/0`).

This is fine for development. For production you will restrict this to your server IP.

Click **Confirm**.

### Step 6 — Get the connection string

Click **Database** in the left sidebar → click **Connect** next to Cluster0.

Click **Drivers**.

- Driver: **Node.js**
- Version: **5.5 or later**

Copy the connection string. It looks like:

```
mongodb+srv://velo_user:<password>@cluster0.XXXXX.mongodb.net/?retryWrites=true&w=majority
```

Replace `<password>` with the password you generated in Step 4.
Replace `?retryWrites` with `/velo_production?retryWrites` (adds the database name).

Final string looks like:
```
mongodb+srv://velo_user:YourPassword123@cluster0.abc12.mongodb.net/velo_production?retryWrites=true&w=majority
```

Paste this as `MONGODB_URI` in your `.env` file.

### Step 7 — Create the database

Click **Browse Collections** → **Add My Own Data**.

- Database name: `velo_production`
- Collection name: `users`

Click **Create**. (Mongoose will create all other collections automatically.)

---

## SECTION 2 — UPSTASH REDIS

**Time: 5 minutes**

### Step 1 — Create account

Go to: https://console.upstash.com

Click **Sign up** → use Google or GitHub → no credit card needed.

### Step 2 — Create a Redis database

Click **Create Database**.

- Name: `velo-cache`
- Type: **Regional** (not Global — Global costs money)
- Region: Pick the same region as your MongoDB cluster
- TLS: **ON** (leave on)
- Eviction: **noeviction** (leave default)

Click **Create**.

### Step 3 — Copy the credentials

After creation you see a dashboard. Scroll to **REST API**.

Copy two values:

1. **UPSTASH_REDIS_REST_URL** — looks like `https://moving-falcon-12345.upstash.io`
2. **UPSTASH_REDIS_REST_TOKEN** — long string starting with `AXXXXXXXXbcdef...`

Paste both into your `.env` file.

**Free tier limits:** 256 MB storage, 500,000 commands/month. This handles ~500 users comfortably.

---

## SECTION 3 — ANTHROPIC API KEY (Claude AI)

**Time: 5 minutes**

### Step 1 — Create account

Go to: https://console.anthropic.com

Click **Get API Access** → sign up with Google or email → verify email.

### Step 2 — Add billing

Click **Billing** in the left sidebar → **Add payment method**.

Add a card. You are NOT charged until you use tokens.

Set a **Usage limit** → click **Set limit** → set monthly limit to **$20** for development. This prevents surprise bills.

### Step 3 — Create an API key

Click **API Keys** in the left sidebar → **Create Key**.

- Name: `velo-backend-dev`
- Click **Create Key**

**Copy the key immediately** — it starts with `sk-ant-api03-`. You cannot see it again after closing the dialog.

Paste as `ANTHROPIC_API_KEY` in your `.env` file.

**Cost check:** At 500 users with 30% DAU and 80% cache hit rate, expect under $3/month. Your $20 limit is safe.

---

## SECTION 4 — GOOGLE GEMINI API KEY

**Time: 5 minutes**

Used for simple AI tasks (feature impact sentences, re-engagement messages) — 30× cheaper than Claude for these.

### Step 1 — Get a key

Go to: https://aistudio.google.com

Click **Get API key** in the top right.

Click **Create API key** → select **Create API key in new project**.

Copy the key — starts with `AIzaSy`.

Paste as `GEMINI_API_KEY` in your `.env` file.

**Free tier:** 15 RPM (requests per minute), 1M tokens/day. More than enough for Phase 1.

---

## SECTION 5 — FIREBASE (Push Notifications)

**Time: 15 minutes**

Firebase Cloud Messaging (FCM) sends push notifications to Android. Free forever, unlimited messages.

### Step 1 — Create Firebase project

Go to: https://console.firebase.google.com

Click **Create a project**.

- Project name: `velo-app` (Firebase will append a random number, e.g. `velo-app-3f2a1`)
- Click **Continue**
- Google Analytics: **Disable** (you can enable later, not needed now)
- Click **Create project**

Wait 30 seconds for it to provision.

### Step 2 — Enable Cloud Messaging

In the left sidebar click **Build** → **Cloud Messaging**.

If it says "Firebase Cloud Messaging API (V1)" — this is already enabled. Good.

If you see a link to enable it in Google Cloud Console, click it and enable the API.

### Step 3 — Generate a service account key

In the left sidebar click the **gear icon** (Project settings) → **Service accounts** tab.

Click **Generate new private key** → **Generate key**.

A JSON file downloads. Open it. It contains:

```json
{
  "type": "service_account",
  "project_id": "velo-app-3f2a1",
  "private_key_id": "abc123",
  "private_key": "-----BEGIN PRIVATE KEY-----\nXXXXXX\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-xxxxx@velo-app-3f2a1.iam.gserviceaccount.com",
  ...
}
```

Copy these three values to your `.env`:

- `project_id` → `FIREBASE_PROJECT_ID`
- `private_key` → `FIREBASE_PRIVATE_KEY` (keep the `\n` characters, wrap in double quotes)
- `client_email` → `FIREBASE_CLIENT_EMAIL`

**Important:** The private key has literal `\n` in it. In your `.env` file it must look like:

```dotenv
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nMIIEvgIBAADANBgkqhkiG9w0BAQEFAASC...\n-----END PRIVATE KEY-----\n"
```

### Step 4 — Download google-services.json for Android

In Firebase console click the **Android icon** (</> icon) under "Get started by adding Firebase to your app."

- Android package name: `com.velo.app` (must match exactly what you use in Capacitor)
- App nickname: `Velo Android`
- Click **Register app**

Download `google-services.json`.

Place this file at: `velo-frontend/android/app/google-services.json`

This file is what tells the Android app which Firebase project to send tokens to.

---

## SECTION 6 — RESEND (Transactional Email)

**Time: 5 minutes**

### Step 1 — Create account

Go to: https://resend.com

Click **Get started for free** → sign up with GitHub or email.

### Step 2 — Verify your domain (or use onboarding address)

For testing, Resend gives you a free onboarding address: `onboarding@resend.dev`

Use this for development. For production you add your own domain.

To add your domain later:
- Click **Domains** → **Add Domain**
- Enter your domain (e.g. `veloapp.com`)
- Add the DNS records Resend shows you to your domain registrar (Cloudflare, Namecheap, etc.)

### Step 3 — Create an API key

Click **API Keys** → **Create API key**.

- Name: `velo-backend`
- Permission: **Sending access** (not full access)
- Domain: Select your verified domain, or **All domains** for development

Copy the key — starts with `re_`.

Paste as `RESEND_API_KEY` in your `.env` file.

Set `RESEND_FROM_EMAIL` to either `onboarding@resend.dev` (testing) or `noreply@yourdomain.com` (production).

**Free tier:** 3,000 emails/month, 100/day. Covers you to ~500 users.

---

## SECTION 7 — GENERATE JWT SECRETS

**Time: 2 minutes**

You need two random 64-byte secrets for signing JWTs. Generate them with Node.js.

Open a terminal and run:

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

Run it twice — once for `JWT_ACCESS_SECRET`, once for `JWT_REFRESH_SECRET`.

Output looks like:
```
a3f8c2e1d4b7a9f0e3c6d2b5a8f1e4c7d0b3a6f9e2c5d8b1a4f7e0c3d6b9a2f5
```

Use different values for each secret. Never use the same value for both.

Paste both into your `.env` file.

---

## SECTION 8 — VERIFY EVERYTHING WORKS

Once your `.env` is complete, run this inside `velo-backend/`:

```bash
npm install
npm run dev
```

You should see:

```
✅ MongoDB connected to cluster0.XXXXX.mongodb.net
✅ Upstash Redis connected
✅ Server running on port 3000
✅ Environment: development
```

If any service fails to connect, the error message will tell you which one and why.

### Test MongoDB:
```bash
curl http://localhost:3000/api/v1/health
```
Should return: `{"success":true,"data":{"db":"connected","cache":"connected"}}`

### Test auth:
```bash
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"TestPass123!"}'
```
Should return a 201 with `accessToken` and `refreshToken`.

### Test push (after Android setup):
```bash
curl -X POST http://localhost:3000/api/v1/users/device-token \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"token":"FCM_TOKEN_FROM_DEVICE","platform":"android"}'
```

### Test email:
Register a new user and check your inbox (or Resend dashboard logs) for the welcome email.

---

## SECTION 9 — DEPLOYING TO RENDER (FREE)

**Time: 10 minutes**

### Step 1 — Create account

Go to: https://render.com → **Get Started for Free** → sign up with GitHub.

### Step 2 — Push your code to GitHub first

```bash
cd velo-backend
git init
git add .
git commit -m "Initial backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/velo-backend.git
git push -u origin main
```

### Step 3 — Create a Web Service on Render

Click **New** → **Web Service** → **Connect a repository** → select `velo-backend`.

Settings:
- Name: `velo-backend`
- Region: Same as your MongoDB (e.g. Frankfurt for EU)
- Branch: `main`
- Runtime: **Node**
- Build command: `npm install && npm run build`
- Start command: `npm start`
- Instance type: **Free**

### Step 4 — Add environment variables

Click **Environment** → **Add Environment Variable**.

Add every variable from your `.env` file one by one. Do NOT upload the `.env` file itself.

The `FIREBASE_PRIVATE_KEY` is tricky — paste the entire value including the quotes and `\n` characters.

Click **Create Web Service**.

Render will build and deploy. First deploy takes 3–5 minutes. Free tier has 512 MB RAM and a 30–60 second cold start when idle.

### Step 5 — Get your backend URL

After deploy you see a URL like `https://velo-backend-xxxx.onrender.com`.

In your Angular project update `src/environments/environment.ts`:
```typescript
export const environment = {
  apiUrl: 'https://velo-backend-xxxx.onrender.com/api/v1'
};
```

---

## SECTION 10 — DEPLOYING ANGULAR TO CLOUDFLARE PAGES (FREE)

**Time: 10 minutes**

### Step 1 — Create account

Go to: https://pages.cloudflare.com → sign up (free, no credit card).

### Step 2 — Connect GitHub

Click **Create a project** → **Connect to Git** → select your Angular frontend repo.

Settings:
- Project name: `velo-app`
- Framework preset: **Angular**
- Build command: `npm run build -- --configuration production`
- Build output directory: `dist/velo-frontend/browser`

Click **Save and Deploy**.

Your Angular app is now live at `https://velo-app.pages.dev`.

---

## SECTION 11 — WHAT TO GIVE CLAUDE CODE

Once all `.env` values are filled in, paste this as your **first message** to Claude Code:

```
I have completed all service account setup. Here is my verified .env file:

[paste your .env here with real values]

Now build the complete Velo backend following the engineering prompt at:
[paste the velo-backend-prompt.md content here]

Start with Sprint 1: folder structure, package.json, tsconfig.json, and environment.ts validation.
When environment.ts loads, it should validate all env vars with Zod and throw a descriptive error
if any are missing. Do not proceed past environment setup until I confirm all vars validate.
```

Claude Code will:
1. Scaffold the entire folder structure
2. Write `environment.ts` with Zod validation of every var
3. Write `database.ts` connecting to your Atlas cluster
4. Write `UpstashCacheService.ts` connecting to your Redis instance
5. Write `FirebasePushService.ts` using your service account JSON
6. Write `ResendEmailService.ts` with your API key
7. Build all 13 modules
8. Run tests — all should pass because your real services are connected

---

## QUICK REFERENCE — ALL URLs

| Service | Dashboard URL | Free tier |
|---------|--------------|-----------|
| MongoDB Atlas | cloud.mongodb.com | 512 MB forever |
| Upstash Redis | console.upstash.com | 256 MB, 500K cmds/mo |
| Anthropic | console.anthropic.com | Pay per token |
| Google Gemini | aistudio.google.com | 15 RPM, 1M tokens/day |
| Firebase | console.firebase.google.com | FCM unlimited forever |
| Resend | resend.com | 3,000 emails/mo |
| Render | render.com | 1 free web service |
| Cloudflare Pages | pages.cloudflare.com | Unlimited bandwidth |
| Google Play | play.google.com/console | £16 one-time |

---

## COMMON ERRORS AND FIXES

### `MongoServerError: Authentication failed`
Wrong password in connection string. Go to Atlas → Database Access → Edit user → Reset password → update MONGODB_URI.

### `UpstashError: Unauthorized`
Wrong token. Go to Upstash console → your database → REST API → copy the token again (they are long and easy to truncate).

### `FirebaseAppError: Failed to determine service account`
The FIREBASE_PRIVATE_KEY has been corrupted. The `\n` characters must be literal backslash-n in the .env file, not actual newlines. Wrap the entire value in double quotes.

### `ResendError: 403 Forbidden`
Your from address domain is not verified yet. Use `onboarding@resend.dev` for testing.

### `JWT malformed` on protected routes
The JWT_ACCESS_SECRET changed after tokens were issued. Clear your browser localStorage and log in again.

### Render cold start (30–60 second first request)
Normal on free tier. Set up a cron ping every 14 minutes using BetterStack or cron-job.org (free) to keep the service warm.
