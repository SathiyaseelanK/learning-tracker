# VELO BACKEND — CLAUDE CODE HANDOFF PROMPT
# Paste this as your FIRST message in a new Claude Code session on your personal machine
# This is a continuation of an existing project with full architecture already designed

---

## WHO YOU ARE

You are a senior backend engineer continuing work on the Velo Life Tracker backend. This project was fully architected in a previous session. You are picking up from where planning ended and writing all code from scratch on a clean personal machine.

Read this entire prompt before writing a single line of code.

---

## WHAT VELO IS

Velo Life Tracker is a personal life-tracking app with:
- Angular 17+ frontend (separate repo: velo-frontend)
- Node.js 20 + TypeScript backend (this repo: velo-backend)
- Android app via Capacitor
- AI companion powered by Claude API (claude-sonnet-4-6)
- Freemium model — free tier hooks users, premium tier ($44.99/year or $7.99/month) unlocks advanced features

The backend replaces a previous Google Apps Script + Google Sheets system entirely.

---

## TECH STACK — NON-NEGOTIABLE

- Runtime: Node.js 20 LTS
- Language: TypeScript 5.x — strict mode ON, zero `any` types
- Framework: Express.js with class-based architecture
- Database: MongoDB via Mongoose (Atlas M0 → Flex → M10)
- Cache: Upstash Redis (HTTP-based, works everywhere)
- Auth: JWT access tokens (15min) + refresh tokens (30 days) with rotation
- Push: Firebase Admin SDK (FCM — free forever)
- Email: Resend SDK
- AI: Anthropic claude-sonnet-4-6 + Google Gemini Flash-Lite (cheap tasks)
- Validation: Zod — every request body AND env var validated
- Logging: Winston structured JSON
- Testing: Jest + Supertest
- Deploy: Render free tier → Oracle Cloud ARM (month 2)

---

## ARCHITECTURE RULES — ABSOLUTE

Every module has exactly 5 class types: Controller · Service · Repository · Model · Validator

- Controller: parse request → call service → return ApiResponse. Zero business logic.
- Service: orchestrate business logic. Zero HTTP concepts (no req/res).
- Repository: MongoDB queries only. Zero business logic.
- Model: Mongoose schema + TypeScript interface. Zero methods.
- Validator: Zod schemas only.

Abstract base classes: every Service extends BaseService, every Repository extends BaseRepository<T>.

Interfaces before implementations: IEmailService, IPushService, IAIService, ICacheService — all injected via constructor, never new'd inside classes.

SOLID throughout. Dependency injection everywhere.

---

## COMPLETE FOLDER STRUCTURE — CREATE ALL OF THESE

```
velo-backend/
├── src/
│   ├── app.ts
│   ├── server.ts
│   ├── config/
│   │   ├── environment.ts        ← Zod validates ALL env vars, singleton
│   │   ├── database.ts           ← MongoDB singleton connection
│   │   └── constants.ts          ← all magic strings/numbers here
│   ├── shared/
│   │   ├── interfaces/
│   │   │   ├── IRepository.ts
│   │   │   ├── ICacheService.ts
│   │   │   ├── IEmailService.ts
│   │   │   ├── IPushService.ts
│   │   │   └── IAIService.ts
│   │   ├── base/
│   │   │   ├── BaseRepository.ts
│   │   │   ├── BaseService.ts
│   │   │   └── BaseController.ts
│   │   ├── errors/
│   │   │   ├── AppError.ts
│   │   │   ├── ValidationError.ts
│   │   │   ├── AuthError.ts
│   │   │   ├── NotFoundError.ts
│   │   │   ├── ConflictError.ts
│   │   │   └── ExternalServiceError.ts
│   │   ├── middleware/
│   │   │   ├── authenticate.ts   ← JWT verify, no DB hit
│   │   │   ├── errorHandler.ts
│   │   │   ├── rateLimiter.ts
│   │   │   ├── requestId.ts
│   │   │   ├── asyncHandler.ts
│   │   │   └── validate.ts
│   │   └── utils/
│   │       ├── ApiResponse.ts    ← always { success, data?, error?, meta? }
│   │       └── tokenUtils.ts
│   ├── infrastructure/
│   │   ├── cache/UpstashCacheService.ts
│   │   ├── email/ResendEmailService.ts
│   │   ├── push/FirebasePushService.ts
│   │   ├── ai/
│   │   │   ├── ClaudeAIService.ts    ← Sonnet 4.6
│   │   │   └── GeminiAIService.ts   ← Flash-Lite for cheap tasks
│   │   └── logger/WinstonLogger.ts
│   └── modules/
│       ├── auth/
│       ├── users/
│       ├── habits/
│       ├── goals/
│       ├── journal/
│       ├── mood/
│       ├── sleep/
│       ├── nutrition/
│       ├── finance/
│       ├── ai-companion/
│       ├── notifications/
│       ├── achievements/
│       └── subscriptions/
├── tests/
│   └── testDatabase.ts           ← mongodb-memory-server
├── .env                          ← gitignored, you fill this in
├── .env.example                  ← committed, placeholder values
├── .gitignore
├── LICENSE
├── README.md
├── package.json
└── tsconfig.json
```

---

## ALL 13 MONGODB SCHEMAS

```typescript
// User
{
  name: String, email: String (unique), passwordHash: String (optional — null for OAuth users),
  googleId: String (optional), facebookId: String (optional),
  tier: enum ['free','premium'], role: enum ['user','admin'],
  onboardingCompleted: Boolean, onboardingData: {
    primaryGoal: String, experienceLevel: enum ['beginner','intermediate','advanced'],
    dailyCommitmentMinutes: Number, selectedFeatures: [String],
    checkinTime: enum ['morning','midday','evening','varies'],
    motivationStyle: enum ['streaks','milestones','daily_progress','accountability'],
    companionStyle: enum ['coach','friend','analyst','sage']
  },
  deviceTokens: [String],   ← FCM tokens
  lastActiveAt: Date, createdAt: Date, updatedAt: Date
}

// RefreshToken
{ userId: ObjectId, tokenHash: String, expiresAt: Date, createdAt: Date }

// Habit
{ userId, name, description, frequency: enum ['daily','weekly','custom'], targetDays: [Number],
  color, icon, isActive, streakCurrent, streakLongest, createdAt }

// HabitLog
{ userId, habitId, completedAt: Date, note: String }

// Goal
{ userId, title, description, category, targetDate, targetValue, currentValue,
  milestones: [{title, targetValue, completedAt}], status: enum ['active','completed','paused'],
  tier: enum ['free','premium'] }

// JournalEntry
{ userId, content, mood: Number 1-10, tags: [String], aiInsight: String, createdAt }

// MoodLog
{ userId, value: Number 1-10, note, factors: [String], createdAt }

// SleepLog
{ userId, bedtime: Date, wakeTime: Date, durationMinutes: Number, quality: Number 1-10,
  factors: [String], createdAt }

// NutritionLog
{ userId, meal: enum ['breakfast','lunch','dinner','snack'], foods: [{name,calories,protein,carbs,fat}],
  totalCalories, createdAt }

// FinanceGoal
{ userId, title, targetAmount, currentAmount, deadline, category, transactions: [{amount,note,date}] }

// AILog
{ userId, type: enum ['onboarding_dashboard','daily_checkin','weekly_report','conversion_pitch',
  'feature_impact','reengagement'], prompt: String, response: String, model: String,
  tokensUsed: Number, cachedAt: Date, createdAt: Date }

// Notification
{ userId, type, title, body, data: Object, read: Boolean, sentAt, createdAt }

// Achievement
{ userId, badgeId: String, earnedAt: Date, xpAwarded: Number }
```

---

## COMPLETE API ROUTES

```
POST   /api/v1/auth/register
POST   /api/v1/auth/login
POST   /api/v1/auth/refresh
POST   /api/v1/auth/logout
POST   /api/v1/auth/logout-all
POST   /api/v1/auth/google        ← Phase 2
POST   /api/v1/auth/facebook      ← Phase 3

GET    /api/v1/users/profile
PATCH  /api/v1/users/profile
POST   /api/v1/users/onboarding
GET    /api/v1/users/onboarding
POST   /api/v1/users/device-token
DELETE /api/v1/users/account

GET    /api/v1/habits
POST   /api/v1/habits
GET    /api/v1/habits/:id
PATCH  /api/v1/habits/:id
DELETE /api/v1/habits/:id
POST   /api/v1/habits/:id/log
GET    /api/v1/habits/:id/logs

GET    /api/v1/goals
POST   /api/v1/goals
PATCH  /api/v1/goals/:id
DELETE /api/v1/goals/:id
PATCH  /api/v1/goals/:id/progress

POST   /api/v1/journal
GET    /api/v1/journal
GET    /api/v1/journal/:id
PATCH  /api/v1/journal/:id
DELETE /api/v1/journal/:id

POST   /api/v1/mood
GET    /api/v1/mood
GET    /api/v1/mood/analytics

POST   /api/v1/sleep
GET    /api/v1/sleep
GET    /api/v1/sleep/analytics

POST   /api/v1/nutrition
GET    /api/v1/nutrition
GET    /api/v1/nutrition/analytics

GET    /api/v1/finance/goals
POST   /api/v1/finance/goals
PATCH  /api/v1/finance/goals/:id
POST   /api/v1/finance/goals/:id/transactions

GET    /api/v1/ai/dashboard        ← generateDashboard (cached 30 days)
GET    /api/v1/ai/checkin          ← getDailyCheckin (cached 23h)
GET    /api/v1/ai/weekly-report    ← getWeeklyReport (cached 6 days, batch)
POST   /api/v1/ai/conversion-pitch ← getConversionPitch (never cached)
GET    /api/v1/ai/feature-impact/:featureId ← getFeatureImpact (cached 7 days, Gemini)
POST   /api/v1/ai/reengagement     ← getReengagementMessage (never cached, Gemini)

GET    /api/v1/notifications
PATCH  /api/v1/notifications/:id/read
POST   /api/v1/notifications/send  ← internal, admin only

GET    /api/v1/achievements
GET    /api/v1/achievements/stats  ← XP total, level, badges

GET    /api/v1/health
```

---

## SECURITY — ALL OF THESE, NO EXCEPTIONS

1. Brute force: express-rate-limit (5 req/15min for register, 10/15min for login)
2. JWT rotation: SHA-256 hash stored, not raw token. Reuse = theft → revoke ALL sessions
3. NoSQL injection: express-mongo-sanitize on all inputs
4. XSS: Helmet.js + xss-clean
5. CORS: whitelist only (ALLOWED_ORIGINS env var)
6. DDoS: Cloudflare Workers gateway (configured separately) + express-slow-down
7. BOLA/IDOR: every repository query scoped to userId — `{ _id: id, userId: req.user.id }`
8. Mass assignment: Zod .strict() on all update DTOs — reject unknown fields
9. ReDoS: body size limit 10kb max
10. HPP: hpp package on all routes
11. Path traversal: file upload magic bytes validation
12. User enumeration prevention: identical error message for wrong email AND wrong password

---

## FREEMIUM SYSTEM — WIRE THIS IN FROM DAY ONE

```typescript
// src/shared/services/FeatureTierService.ts
// Single source of truth for what is free vs premium
// Change tier here → propagates everywhere automatically

export const FEATURE_TIERS = {
  habits: { basic: 'free', unlimited: 'premium', aiInsights: 'premium' },
  goals: { basic: 'free', advanced: 'premium', aiCoaching: 'premium' },
  journal: { basic: 'free', aiReflections: 'premium' },
  mood: { basic: 'free', analytics: 'premium' },
  sleep: { basic: 'free', analytics: 'premium' },
  nutrition: { basic: 'free', macroTracking: 'premium' },
  finance: { basic: 'premium' },           ← entire module is premium
  ai_checkin: { daily: 'premium' },         ← AI check-in is premium
  ai_weekly_report: { full: 'premium' },
  achievements: { basic: 'free', advanced: 'premium' },
} as const;

// Middleware to inject into any premium route:
// tierGuard('premium') → checks user.tier → 403 if free with upgrade message
```

The upgrade message returned on 403 MUST contain:
- `code: 'UPGRADE_REQUIRED'`
- `feature: string`  
- `message: string` (never use "sorry", "unfortunately", "blocked")
- `upgradeUrl: '/premium'`

---

## AI COMPANION SERVICE — EXACT IMPLEMENTATION

```typescript
// VeloAiService — routes each call to the right model + caches correctly

getDashboard(userId)        → claude-sonnet-4-6,  cache 30 days in Redis
getDailyCheckin(userId)     → claude-sonnet-4-6,  cache 23h in Redis
getConversionPitch(userId)  → claude-sonnet-4-6,  NO cache (emotional moment)
getWeeklyReport(userId)     → gemini-flash (batch queue, Sunday nights, cache 6 days)
getFeatureImpact(featureId) → gemini-flash-lite,  cache 7 days (simple 1-sentence task)
getReengagementMessage()    → gemini-flash-lite,  NO cache
getPushCopy()               → groq/llama (free tier), no cache, real-time
```

Cache key pattern: `ai:{userId}:{type}:{date?}`

Fallback: if AI call fails → return pre-written fallback from constants, never expose error to user.

---

## ENV VARS (all validated by Zod in environment.ts)

```env
NODE_ENV=development
PORT=3000
API_VERSION=v1
FRONTEND_URL=http://localhost:4200
ALLOWED_ORIGINS=http://localhost:4200

JWT_ACCESS_SECRET=     ← 64-byte hex
JWT_REFRESH_SECRET=    ← different 64-byte hex
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=30d

MONGODB_URI=           ← Atlas connection string with /velo_production
MONGODB_DB_NAME=velo_production

UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=

ANTHROPIC_API_KEY=
GEMINI_API_KEY=

FIREBASE_PROJECT_ID=
FIREBASE_PRIVATE_KEY=  ← "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=

RESEND_API_KEY=
RESEND_FROM_EMAIL=onboarding@resend.dev
RESEND_FROM_NAME=Velo

RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
AUTH_RATE_LIMIT_MAX=10

LOG_LEVEL=debug
LOG_FORMAT=json
```

---

## BUILD ORDER — DO IN THIS EXACT SEQUENCE

1. package.json + tsconfig.json + .env.example + .gitignore + LICENSE
2. config/environment.ts — Zod validate all env vars. STOP AND CONFIRM before proceeding.
3. config/database.ts — MongoDB singleton
4. shared/errors/ — all error classes
5. shared/interfaces/ — all interfaces
6. shared/base/ — BaseRepository, BaseService, BaseController
7. shared/middleware/ — all middleware
8. shared/utils/ApiResponse.ts
9. infrastructure/logger/ — Winston
10. infrastructure/cache/ — UpstashCacheService
11. infrastructure/email/ — ResendEmailService
12. infrastructure/push/ — FirebasePushService
13. infrastructure/ai/ — ClaudeAIService + GeminiAIService
14. app.ts + server.ts — wire everything together
15. modules/auth/ — full auth module with tests
16. modules/users/ — profile + onboarding
17. modules/habits/ — with streak calculation
18. modules/goals/
19. modules/journal/
20. modules/mood/
21. modules/sleep/
22. modules/nutrition/
23. modules/finance/
24. modules/ai-companion/ — VeloAiService wiring all AI calls
25. modules/notifications/
26. modules/achievements/ — XP + badges
27. modules/subscriptions/ — [BILLING_WIRE_HERE] stubs only, no real billing yet
28. GET /api/v1/health endpoint
29. tests/ — auth unit tests + integration tests
30. README.md with setup guide

After step 2 (environment.ts), STOP. Do not proceed until I confirm all env vars validate.
After step 15 (auth module), STOP. Do not proceed until I test register/login/refresh manually.

---

## QUALITY CHECKLIST — VERIFY BEFORE CALLING DONE

- [ ] `npm run build` passes with zero TypeScript errors
- [ ] `npm test` passes — all auth tests green
- [ ] `curl /api/v1/health` returns `{"success":true,"data":{"db":"connected","cache":"connected"}}`
- [ ] Register → receive accessToken + refreshToken
- [ ] Login → tokens returned
- [ ] Use access token → protected route works
- [ ] Refresh → old token invalidated, new pair returned
- [ ] Reuse old refresh token → all sessions revoked (theft detection)
- [ ] Send `role: admin` in profile update → rejected (mass assignment blocked)
- [ ] No `console.log` anywhere — all logging through Winston
- [ ] No hardcoded strings — all in constants.ts or environment.ts
- [ ] Every MongoDB query scoped to userId
- [ ] All env vars in .env.example with placeholder values

---

## START COMMAND

After reading this entire prompt, begin with:
"Starting Sprint 1. Creating package.json, tsconfig.json, .gitignore, .env.example, and LICENSE file."

Then proceed to step 2 (environment.ts) and pause for my confirmation.
