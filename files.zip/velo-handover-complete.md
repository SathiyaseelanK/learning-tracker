# VELO LIFE TRACKER — COMPLETE HANDOVER DOCUMENT
# New Claude chat: paste this entire document as your first message
# Date: 29 September 2026 | Target launch: 1 November 2026

---

## 1. WHAT VELO IS

Velo Life Tracker is a personal life-tracking Angular PWA + Android app (Capacitor)
with an AI companion powered by Claude API. Tracks: habits, goals, journal, mood,
sleep, nutrition, finance, Pomodoro focus time, achievements.

One-sentence pitch:
"The only app that connects your sleep, mood, habits, money, and goals — with an
AI companion that remembers everything and tells you what's actually going on."

Play Store description (350 chars):
"Velo is your AI life companion. Track habits, sleep, mood, goals, journal,
nutrition, finance, and focus — all in one app. Unlike other trackers, Velo's AI
connects the dots across your whole life, spotting patterns no single tracker can
see. Daily check-ins feel genuinely personal. One app. An AI that actually knows you."

Business model: Freemium
- Free tier: hooks users with limited features
- Premium: £44.99/year (lead plan) · £7.99/month (fallback) · £89.99 lifetime (launch promo, retire month 6)
- Google Play takes 15% commission under $1M/year

---

## 2. TECH STACK — ALL DECIDED, NOTHING TO RE-DECIDE

### Frontend
- Angular 17+ standalone components throughout
- Angular Signals for all reactive state
- Capacitor 5+ for Android
- Firebase FCM for push notifications (free forever)
- Cloudflare Pages for hosting (free, unlimited bandwidth)
- TypeScript strict mode — zero `any` types

### Backend
- Node.js 20 LTS + TypeScript strict
- Express.js with class-based OOP architecture
- MongoDB Atlas via Mongoose (M0 free → Flex → M10)
- Upstash Redis for AI response caching (HTTP-based)
- JWT auth: 15min access tokens + 30-day refresh tokens with rotation
- Resend for transactional email
- Firebase Admin SDK (FCM push)
- Winston structured JSON logging
- Zod validation on every request body AND every env var
- Jest + Supertest for testing

### AI routing (hybrid — cost optimised)
- Claude Sonnet 4.6 → onboarding dashboard, daily check-in, conversion pitch
- Gemini Flash → weekly reports (4× cheaper than Sonnet)
- Gemini Flash-Lite → feature impact sentences, re-engagement (30× cheaper)
- Groq free tier (Llama 3.1 8B) → push notification copy, classifiers

### Hosting by phase
- Phase 1: Render free tier (backend) + Cloudflare Pages (frontend)
- Phase 2 (month 2): Oracle Cloud Always Free ARM 4-core 24GB (no cold starts, free forever)
- Database: Atlas M0 free → Flex at ~2k users → M10 at ~5k users

---

## 3. ARCHITECTURE — DECIDED AND FINAL

### Pattern
Modular monolith. Every module has exactly 5 class types:
Controller → Service → Repository → Model → Validator

Rules:
- Controller: parse request → call service → return ApiResponse. Zero business logic.
- Service: business logic only. Zero HTTP concepts (no req/res).
- Repository: MongoDB queries only. Zero business logic.
- Model: Mongoose schema + TypeScript interface. Zero methods.
- Validator: Zod schemas only.

Abstract base classes: BaseRepository<T>, BaseService, BaseController
Interfaces: IRepository<T>, IEmailService, IPushService, IAIService, ICacheService
All injected via constructor — never `new`'d inside classes.

### Error hierarchy
AppError → ValidationError(400), AuthError(401), ForbiddenError(403),
NotFoundError(404), ConflictError(409), ExternalServiceError(502)

### API response shape
{ success: boolean, data?, error?: { code, message, details? }, meta?: { page, limit, total, timestamp, requestId } }

### 13 modules
auth, users, habits, goals, journal, mood, sleep, nutrition, finance,
ai-companion, notifications, achievements, subscriptions

---

## 4. AUTH SYSTEM — DECIDED AND FINAL

### What is built at launch
Email + password only. JWT is stateless — auth costs £0 at any scale.

### Signup flow
Rate limit (5/15min/IP) → Zod validate → MongoDB email check → bcrypt.hash(pw, 12)
→ create user → generate JWT accessToken (15min) + random refreshToken (30 days)
→ store SHA-256 hash of refresh token in MongoDB (never raw)
→ fire Resend welcome email async → return { accessToken, refreshToken }

### Login flow
Rate limit (10/15min/IP) → findByEmail → bcrypt.compare()
→ SAME error message for wrong email AND wrong password (prevents enumeration)
→ generate token pair → store hashed refresh → return tokens

### Protected routes
jwt.verify() — pure cryptography, zero DB hit. User id/email/role/tier in JWT payload.

### Token refresh
Hash incoming token → lookup in MongoDB
→ NOT FOUND = theft detected → revoke ALL sessions for user (token family invalidation)
→ FOUND = delete old token + issue fresh pair (rotation)

### Auth roadmap
- Phase 2 (month 2): Google OAuth — free forever, +25-40% signup conversion, 3-5 days work
- Phase 3 (month 6+): Facebook OAuth — only if analytics show demand (Meta review takes 1-2 weeks)
- Phase 3 (month 6+): SMS OTP — only if signup drop-off data justifies £150-750/month cost
  CRITICAL: Set Firebase Phone Auth daily spend cap BEFORE enabling SMS OTP. Fraud risk is real.

### Account linking
If Google email matches existing password account → merge (add googleId to user doc)
Never create duplicate accounts for same email.

---

## 5. SECURITY — ALL 12 IMPLEMENTED

1. Brute force: express-rate-limit (5/15min register, 10/15min login)
2. JWT rotation: SHA-256 hash stored, reuse = theft → revoke ALL sessions
3. NoSQL injection: express-mongo-sanitize
4. XSS: Helmet.js + xss-clean
5. CORS: whitelist only (ALLOWED_ORIGINS env var)
6. DDoS: Cloudflare Workers gateway + express-slow-down
7. BOLA/IDOR: every MongoDB query scoped to userId
8. Mass assignment: Zod .strict() on all update DTOs
9. ReDoS: body size limit 10kb
10. HPP: hpp package
11. Path traversal: magic bytes file validation
12. User enumeration: identical error for wrong email AND wrong password

---

## 6. FREEMIUM SYSTEM — DECIDED AND FINAL

FeatureTierService is single source of truth for free vs premium.
Change tier in one place → propagates everywhere automatically.
Feature tier split not yet finalised — placeholders in code for now.

### 7 conversion triggers (each fires once per user lifetime, max 1/day)
- day3_insight_teaser
- streak_7_milestone
- free_limit_reached
- premium_feature_first_touch
- weekly_report_tease
- goal_progress_plateau
- day30_milestone

### Upgrade modal rules — NEVER use these words
"sorry" · "unfortunately" · "upgrade" as verb CTA · "buy now"
"blocked" · "locked" · "premium only"

### 403 response shape
{ code: 'UPGRADE_REQUIRED', feature: string, message: string, upgradeUrl: '/premium' }

---

## 7. AI COMPANION — DECIDED AND FINAL

### VeloAiService — 7 methods with cache TTLs
- generateDashboard()       → Sonnet 4.6,       cache 30 days (runs once per user)
- getDailyCheckin()         → Sonnet 4.6,       cache 23h (80% hit rate = 72% cost reduction)
- getConversionPitch()      → Sonnet 4.6,       NO cache (emotional moment)
- getWeeklyReport()         → Gemini Flash,     Batch API Sunday night, cache 6 days
- getFeatureImpact(id)      → Gemini Flash-Lite, cache 7 days (1 sentence, 30× cheaper)
- getReengagementMessage()  → Gemini Flash-Lite, NO cache
- getPushCopy()             → Groq free tier,   real-time

Cache key pattern: ai:{userId}:{type}:{date?}
Fallback: if AI fails → return pre-written constant, never expose error to user.

### Onboarding wizard (5 steps)
Step 1: Why (free text + experience level: beginner/intermediate/advanced)
Step 2: Commitment (10/30/60 min/day)
Step 3: Feature grid — ALL 10 features shown, premium marked ⭐ only (no "premium" text)
Step 4: Lifestyle (checkin time: morning/midday/evening/varies · motivation style)
Step 5: Companion personality (coach/friend/analyst/sage)

After step 5: loading screen → generateDashboard() → navigate /dashboard

### Dashboard layout
- Free modules: fully interactive
- Premium features user selected: blurred + frosted overlay + "Unlock with Velo Premium"
- Features not selected: hidden entirely
- Bottom section: "Premium horizon" — 2-3 unselected premium features with AI impact sentences

### Companion personality tone rules
Coach: direct and challenging ("You said you wanted this. Prove it today.")
Friend: warm and celebratory ("Look at you showing up again!")
Analyst: data-focused ("Your 7-day trend shows X — here's what that means")
Sage: reflective and calm ("Consistency is just showing up. You showed up. That's enough.")

---

## 8. PRICING STRATEGY — DECIDED AND FINAL

Lead plan:   £44.99/year — shown first, selected by default, badged "Most popular"
             Show as "£3.75/month" not "£44.99/year" as the headline
Monthly:     £7.99/month — job is to make annual look like obvious deal (53% saving)
Lifetime:    £89.99 one-time — launch promo only, retire after month 6

Data from 115,000 real apps (RevenueCat SOIS 2026):
- Annual subscribers retain at 44.1% after 12 months vs 17.5% monthly
- 59% of users choose annual when shown 30-40% discount vs monthly
- High-priced apps convert at 9.8% vs 4.3% for low-priced (price signals quality)
- AI apps earn 41% LTV premium over non-AI apps

Paywall timing: NEVER on app open. Show after:
- Onboarding AI dashboard loads (user sees personalised insights)
- 7-day streak milestone (highest emotional moment in app)
- Conversion trigger fires
- User taps a blurred premium feature

---

## 9. COSTS — VERIFIED SEPTEMBER 2026

### Monthly running costs by phase
Phase 1 (0-500 users):       ~£2.20/month — only AI costs money
Phase 2 (500-5,000 users):   ~£26-50/month — email biggest cost (Resend Pro £16)
Phase 3 (5,000-25,000 users): ~£148/month — MongoDB M10 biggest cost (£45)
Phase 4 (25,000-100,000):    ~£423/month = 0.85% of £49,900/month revenue

### AI costs with hybrid routing (500 users, 80% cache hit)
~$4/month total. Daily check-in: ~£0.85/month. Onboarding dashboard: ~£1.30/month.

### Total to build and run 12 months
Without SMS OTP: ~£526 total
With SMS OTP Phase 3: adds £900-4,500

### Service pricing (verified September 2026)
MongoDB Atlas M0: free (512MB) → Flex ($8-30/mo cap) → M10 ($57/mo)
Upstash Redis:    free (500K cmds/mo) → pay-as-go ($0.0002/cmd)
Anthropic API:    Sonnet 4.6 $3/$15 per MTok · cache reads 10% · Batch 50% off
Gemini:           Flash-Lite $0.10/$0.40 per MTok · Flash $0.75/$3.75 (promo Dec 2026)
Firebase FCM:     free forever, unlimited push
Resend:           free 3k/mo → Pro $20/mo
Render:           free (512MB, 30-60s cold start)
Oracle Cloud:     always free (4 cores, 24GB RAM, no cold starts)
Cloudflare Pages: free, unlimited bandwidth

### Development cost
Claude Code Pro: $20/month (~£16). Expected total dev cost: ~£50-80 for full build.
IMPORTANT: If ANTHROPIC_API_KEY is set in your shell, Claude Code uses API billing
(NOT your subscription). Run `echo $ANTHROPIC_API_KEY` — if anything prints, unset it.

---

## 10. GITHUB SETUP — DONE

Two private repos on personal GitHub account (NOT work Accenture account):
- git@github-personal:YOUR_USERNAME/velo-backend (private, All Rights Reserved)
- git@github-personal:YOUR_USERNAME/velo-frontend (private, All Rights Reserved)

SSH config file (~/.ssh/config):
  Host github.com         → work account (id_ed25519)
  Host github-personal    → personal/Velo account (id_ed25519_personal)

Git identity set per-repo with personal email (NOT --global).
Branch strategy: work on `dev` branch, merge to `main` when sprint complete.
Licence: All Rights Reserved (proprietary commercial, not open source).

---

## 11. LEGAL NOTE — IMPORTANT

Currently employed at Accenture. Velo code has been moved to personal machine
and personal email. All development now on personal equipment only.
Do not reference Accenture in any code, commits, or accounts.

BEFORE public launch or monetisation: consult an employment solicitor regarding
IP ownership clauses in Accenture employment contract.
Recommendation: Solicitors.lawsociety.org.uk — search for employment/IP specialists.
Estimated cost: £150-300 for one-hour consultation.

---

## 12. NOVEMBER LAUNCH PLAN — REVISED TIMELINE

Today: 29 September 2026. Target public launch: 1 November 2026.
33 days. Claude Code writes ~95% of code.

WEEK 1 (29 Sep – 5 Oct) — YOU: service account setup
  Create all accounts (MongoDB Atlas, Upstash, Anthropic, Gemini, Firebase, Resend)
  Fill .env file · Generate JWT secrets · Push repos to GitHub
  Install Claude Code Pro · Verify health check passes

WEEK 2 (6 – 12 Oct) — CLAUDE CODE: backend foundation + auth
  Folder structure · all 13 schemas · environment Zod validation
  Auth module (register/login/refresh/logout) · all security middleware · tests
  CHECKPOINT: test register + login manually before proceeding

WEEK 3 (13 – 19 Oct) — CLAUDE CODE: all feature modules + AI service
  habits · goals · journal · mood · sleep · nutrition · finance
  ai-companion · notifications · achievements · subscriptions stubs
  VeloAiService with all 7 methods + caching + Gemini routing
  PARALLEL: Frontend migration starts (replace Google Sheets calls)

WEEK 4 (20 – 26 Oct) — CLAUDE CODE: new frontend screens
  5-step onboarding wizard · AI dashboard · freemium overlays
  Floating companion panel · ConversionTriggerService · upgrade modal

WEEK 5 (27 – 31 Oct) — CLAUDE CODE + YOU: Android + deployment
  Capacitor setup · FCM push notifications
  GitHub Actions CI/CD · Render deploy · Cloudflare Pages deploy
  Google Play internal testing track submitted
  End-to-end test on real Android device

1 NOVEMBER — PUBLIC LAUNCH
  Google Play production · web app live · Play Store listing complete
  First Reddit post · first build-in-public post on X/Twitter

POST-LAUNCH (November):
  Week 7-8: Google OAuth (free, +25-40% signup lift)
  Week 7-8: Oracle Cloud migration (eliminate cold starts)
  Week 9-10: ASO update for January New Year keywords
  Week 11-12: Achievements + discover page + ProductHunt launch (Tuesday 15 Dec)
  1 January 2027: January New Year wave — 2-4× normal downloads

WHY NOVEMBER MATTERS:
  HabitKit earned $112K in January 2025 alone.
  Apps indexed with 20+ reviews by December catch this wave for free.
  Launching in December misses it entirely.

---

## 13. MARKETING PLAN — ZERO BUDGET

Daily schedule (45 min/day):
  Monday:    One Reddit post about a problem (not about Velo) — r/selfimprovement, r/productivity
  Tuesday:   One build-in-public update on X/Twitter with one real number
  Wednesday: Check Play Store keyword rankings, update 3-5 keywords
  Thursday:  Record one 30-second screen recording showing a real AI insight for TikTok/Reels
  Friday:    Email 3 active users for a 15-minute voice note call
  Saturday:  Batch next week's content drafts
  Sunday:    Rest. Do not touch metrics.

Special events:
  Week 6 after launch: ProductHunt (Tuesday for max visibility)
  Week 8: Indie Hackers "Show IH" post with real revenue numbers
  October/November: Update all ASO metadata for January keywords before December

Paid ads: DO NOT start until 100+ reviews, Day 30 retention above 8%, and iOS live.
Paid CPI is £2-5 per install. At current retention rates, payback period = decades.

---

## 14. REVENUE PROJECTIONS

Market: $2.22B globally, 14.2% CAGR, 298M active users. AI demand +34% in 2024.

Scenario A (60% probability): ~£12,000 Year 1 (organic only)
Scenario B (30% probability): ~£48,000 Year 1 (Reddit + build in public)
Scenario C (10% probability): ~£180,000 Year 1 (viral/ProductHunt moment)
Expected Year 1 profit (probability-weighted): ~£33,100

Comparable apps:
- HabitKit (solo dev, no AI, no team): $602K in 2025, $112K in January alone
- Habit Pixel: $1K MRR in 8 months, freemium $4.99/month

Velo's unfair advantage: cross-data AI. No competitor connects sleep + mood + habits
+ finance + journal + goals and draws conclusions across all of them.

---

## 15. COMPETITIVE POSITION

All competitors have ✗ for cross-data AI. Velo has ✓. This is the only column that matters.

HabitKit:  habits only, no AI, GitHub-style grid visual identity, $602K/year
Finch:     habits + mood, virtual pet (no real AI), 10M downloads
Habitica:  gamified habits only, party system for social accountability
Bearable:  habits + mood, symptom correlations only, no finance/journal/sleep
Streaks:   habits only, iOS only, one-time purchase £5.99
Habitify:  habits only, 7 free habits limit, no AI

Velo's gaps to fix post-launch:
1. No single visual identity (fix: "Life Score" 0-100 widget — hero screenshot)
2. Android only (fix: iOS in month 6-9 if growth validates)
3. No social layer (fix: accountability partner email share, Phase 3)
4. No wearable integration (fix: Samsung Health + Health Connect, Phase 3)
5. English only (fix: ASO metadata in Hindi/German/French/Spanish, month 3, free)

---

## 16. FILES ALREADY CREATED (DOWNLOAD FROM PREVIOUS CHAT)

All 5 files were created and offered for download in the previous conversation.

FILE 1: velo-backend-prompt.md (2,084 lines)
  Full Claude Code prompt for entire backend. Contains: complete OOP architecture,
  all 13 MongoDB schemas with all fields, all API routes, all security middleware,
  build order (34 steps), quality checklist.
  USE: paste into Claude Code backend session as context/reference.

FILE 2: velo-services-setup.md (599 lines)
  Step-by-step guide for creating every service account.
  Covers: MongoDB Atlas (7 steps), Upstash Redis (3 steps), Anthropic API (4 steps),
  Gemini (2 steps), Firebase FCM (6 steps), Resend (3 steps), JWT secrets (2 steps),
  Render deploy (5 steps), Cloudflare Pages (2 steps).
  Includes: common errors and fixes for every service.
  USE: follow this during Week 1 setup.

FILE 3: velo-backend-handoff.md (448 lines)
  Complete Claude Code prompt for backend — paste as FIRST message in backend session.
  Contains: full folder structure, all 13 schemas, complete API routes, security rules,
  freemium system, AI service spec, all env vars, build order with checkpoints.
  USE: paste as first message when opening Claude Code in velo-backend/ folder.

FILE 4: velo-frontend-handoff.md (400 lines)
  Complete Claude Code prompt for frontend — paste as FIRST message in frontend session.
  Contains: existing code migration plan (Google Sheets → new API), all new screens spec
  (onboarding wizard, dashboard, companion panel, upgrade modal, discover page,
  achievements), Capacitor Android setup, routing structure, build order with checkpoints.
  USE: paste as first message when opening Claude Code in velo-frontend/ folder.

FILE 5: velo-services-setup.md (already listed above as FILE 2)

---

## 17. ENV VARS — COMPLETE LIST

```
NODE_ENV=development
PORT=3000
API_VERSION=v1
FRONTEND_URL=http://localhost:4200
ALLOWED_ORIGINS=http://localhost:4200,http://localhost:3000

JWT_ACCESS_SECRET=     [64-byte hex — node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"]
JWT_REFRESH_SECRET=    [different 64-byte hex]
JWT_ACCESS_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=30d

MONGODB_URI=           [Atlas string with /velo_production before the ?]
MONGODB_DB_NAME=velo_production

UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=

ANTHROPIC_API_KEY=     [sk-ant-api03-...]
GEMINI_API_KEY=        [AIzaSy...]

FIREBASE_PROJECT_ID=
FIREBASE_PRIVATE_KEY=  ["-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"]
FIREBASE_CLIENT_EMAIL=

RESEND_API_KEY=        [re_...]
RESEND_FROM_EMAIL=onboarding@resend.dev
RESEND_FROM_NAME=Velo

GOOGLE_CLIENT_ID=      [Phase 2 only — leave blank for now]
GOOGLE_CLIENT_SECRET=  [Phase 2 only — leave blank for now]

RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
AUTH_RATE_LIMIT_MAX=10

LOG_LEVEL=debug
LOG_FORMAT=json
```

---

## 18. WHAT IS DONE vs WHAT IS NEXT

### COMPLETED
- [x] Full product architecture designed
- [x] All service accounts identified
- [x] Complete backend Claude Code prompt written (2,084 lines)
- [x] Complete frontend Claude Code prompt written (400 lines)
- [x] Service setup guide written (599 lines)
- [x] Two private GitHub repos created on personal account
- [x] SSH config set up for two GitHub accounts on one machine
- [x] Moving code from work laptop to personal machine
- [x] Purchasing Claude Code Pro ($20/month)
- [x] November launch plan finalised

### NEXT — IN THIS EXACT ORDER

Week 1 (by 5 Oct):
  [ ] Create MongoDB Atlas account + cluster + user + get connection string
  [ ] Create Upstash Redis account + database + copy REST URL and token
  [ ] Create Anthropic account + add billing + set $20 limit + create API key
  [ ] Create Gemini API key at aistudio.google.com
  [ ] Create Firebase project + enable FCM + download service account JSON
  [ ] Create Resend account + create API key
  [ ] Generate two JWT secrets in terminal (crypto.randomBytes)
  [ ] Fill in velo-backend/.env with all real values
  [ ] Run `npm install && npm run dev` in velo-backend
  [ ] Confirm health check: curl http://localhost:3000/api/v1/health returns db:connected

Week 2 (6-12 Oct):
  [ ] Open terminal in velo-backend/ → run `claude`
  [ ] Paste velo-backend-handoff.md as first message
  [ ] Confirm environment.ts validates (checkpoint 1)
  [ ] Test auth manually: register → login → refresh → protected route (checkpoint 2)

Week 3 (13-19 Oct):
  [ ] Continue Claude Code backend: all 13 feature modules + VeloAiService
  [ ] Open second terminal in velo-frontend/ → run `claude`
  [ ] Paste velo-frontend-handoff.md as first message
  [ ] Confirm Google Sheets calls replaced with new API (checkpoint 3)

Week 4 (20-26 Oct):
  [ ] New screens: onboarding wizard + dashboard + companion panel + upgrade modal

Week 5 (27-31 Oct):
  [ ] Capacitor Android setup + FCM push notifications
  [ ] CI/CD: GitHub Actions → Render + Cloudflare Pages
  [ ] Submit to Google Play internal testing track
  [ ] Test end-to-end on real Android device

1 November:
  [ ] Google Play production release
  [ ] Web app live at your domain
  [ ] First Reddit post published
  [ ] First build-in-public post on X/Twitter

Post-launch (before December):
  [ ] Consult employment solicitor before monetising
  [ ] Google OAuth (month 2)
  [ ] Oracle Cloud migration (month 2)
  [ ] ASO metadata update for January New Year keywords
  [ ] ProductHunt launch (Tuesday 15 December)

---

## 19. HOW TO WORK WITH CLAUDE CODE

Two separate sessions — one per repo:

BACKEND SESSION:
  cd velo-backend
  claude
  [paste velo-backend-handoff.md as first message]
  [after environment.ts → STOP, confirm env vars validate]
  [after auth module → STOP, test register/login manually]
  [then continue sprints]

FRONTEND SESSION (start after backend health check passes):
  cd velo-frontend
  claude
  [paste velo-frontend-handoff.md as first message]
  [Claude Code reads existing code first, lists Google Sheets calls]
  [confirm migration plan before it changes anything]
  [after Google Sheets replaced → STOP, test existing features]
  [then build new screens]

Claude Code does not remember between sessions. The handoff prompts contain
everything it needs — no context is lost when starting a new session.

Warning: if ANTHROPIC_API_KEY is set in shell, Claude Code uses API billing
(not your $20 subscription). Run: echo $ANTHROPIC_API_KEY
If anything prints: unset ANTHROPIC_API_KEY

---

## 20. FIRST THING TO DO RIGHT NOW

1. Open velo-services-setup.md (already downloaded)
2. Start at Section 1 — MongoDB Atlas
3. Follow every step exactly as written
4. Do not skip to coding until .env is complete and health check passes

The handover is complete. Everything needed to build and launch Velo is in this
document and the 4 downloaded files. Continue from wherever you are.
