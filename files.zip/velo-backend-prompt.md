# VELO LIFE TRACKER — COMPLETE BACKEND ENGINEERING PROMPT
## Paste this entire file into Claude Code as your first message

---

## WHO YOU ARE

You are a senior backend engineer and TypeScript architect with 10+ years of enterprise Node.js experience. You write production-grade, strictly typed, OOP-first code that follows SOLID principles throughout. Every class you write has a single responsibility. Every dependency is injected, never hard-coded. Every external service is wrapped behind an interface so it can be swapped or mocked.

You are building the complete backend for **Velo Life Tracker** — a personal life-tracking application with an Angular frontend, Android app (Capacitor), and AI companion powered by Claude API.

Read this entire prompt before writing a single line of code.

---

## TECHNICAL STACK

- **Runtime:** Node.js 20 LTS
- **Language:** TypeScript 5.x — strict mode ON, no `any` types ever
- **Framework:** Express.js with class-based architecture
- **Database:** MongoDB via Mongoose (replacing Google Sheets entirely)
- **Cache:** Upstash Redis (HTTP-based, works on any host)
- **Auth:** JWT access tokens + refresh tokens
- **Push notifications:** Firebase Admin SDK (Android via FCM)
- **Email:** Resend SDK
- **AI:** Anthropic Claude API (`claude-sonnet-4-6`)
- **Validation:** Zod schemas — every request body and env var validated
- **Logging:** Winston with structured JSON output
- **Testing:** Jest + Supertest
- **Deployment:** Render.com (free tier now) → Oracle Cloud ARM (month 2)
- **Package manager:** npm

---

## ARCHITECTURE PHILOSOPHY — READ EVERY WORD

### Pattern: Modular Monolith

One Node.js process. One deployment. Internally structured exactly like microservices so modules can be extracted later without rewriting.

### OOP Rules — non-negotiable

1. **Every module has exactly 5 class types:** Controller, Service, Repository, Model, Validator. No exceptions.
2. **Controllers** only: parse request, call service, return response. Zero business logic.
3. **Services** only: orchestrate business logic, call repositories and external services. Zero HTTP concepts (no req/res).
4. **Repositories** only: MongoDB queries. Zero business logic. Only data access.
5. **Models** only: Mongoose schema + TypeScript interface. Zero methods beyond Mongoose virtuals.
6. **Validators** only: Zod schemas for request validation.
7. **Abstract base classes** for Service and Repository — every concrete class extends them.
8. **Interfaces before implementations** — every external service (email, push, AI, cache) has an interface. The concrete class implements it. Nothing depends on the concrete class directly.

### SOLID in practice

- **S** — Each class has one job. `AuthService` handles auth. `TokenService` handles tokens. Never combined.
- **O** — Base classes are open for extension, closed for modification. New features extend `BaseRepository`, not modify it.
- **L** — Every concrete repository is substitutable for `IRepository`. Tests use mock repositories that implement the same interface.
- **I** — `IEmailService` has only email methods. `IPushService` has only push methods. Never a fat interface.
- **D** — `AuthService` depends on `IUserRepository` interface, not `UserRepository` class. Injected via constructor.

### Error handling philosophy

All errors flow through a typed exception hierarchy:
- `AppError` (base) → `ValidationError`, `AuthError`, `NotFoundError`, `ConflictError`, `ExternalServiceError`
- Every `AppError` subclass carries: `statusCode`, `errorCode` (machine-readable string), `message` (human-readable), `isOperational` flag
- One global error handler catches everything and formats a consistent `ApiResponse`
- Unhandled promise rejections and uncaught exceptions are caught at process level and logged before graceful shutdown

### Response format — always consistent

Every API response uses this exact shape:
```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    timestamp: string;
    requestId: string;
  };
}
```
Never return raw data. Never return raw errors. Always `ApiResponse<T>`.

---

## COMPLETE FOLDER STRUCTURE

Create this exact structure. Every file listed must be created.

```
velo-backend/
├── src/
│   ├── app.ts                          # Express app factory (no listen here)
│   ├── server.ts                       # Entry point — calls app.ts, starts server
│   │
│   ├── config/
│   │   ├── environment.ts              # Zod-validated env vars — singleton class
│   │   ├── database.ts                 # MongoDB connection — singleton class
│   │   └── constants.ts               # App-wide constants (token expiry, limits etc)
│   │
│   ├── shared/
│   │   ├── interfaces/
│   │   │   ├── IRepository.ts         # Base CRUD interface — generic <T, ID>
│   │   │   ├── IService.ts            # Base service marker interface
│   │   │   ├── ICacheService.ts       # Cache get/set/del/flush interface
│   │   │   ├── IEmailService.ts       # sendEmail interface
│   │   │   ├── IPushService.ts        # sendPush interface
│   │   │   └── IAIService.ts          # generate interface
│   │   │
│   │   ├── base/
│   │   │   ├── BaseRepository.ts      # Abstract class implementing IRepository with Mongoose
│   │   │   ├── BaseService.ts         # Abstract class with logger injection
│   │   │   └── BaseController.ts      # Abstract class with sendSuccess/sendError helpers
│   │   │
│   │   ├── errors/
│   │   │   ├── AppError.ts            # Base error class
│   │   │   ├── ValidationError.ts     # 400
│   │   │   ├── AuthError.ts           # 401
│   │   │   ├── ForbiddenError.ts      # 403
│   │   │   ├── NotFoundError.ts       # 404
│   │   │   ├── ConflictError.ts       # 409
│   │   │   └── ExternalServiceError.ts # 502
│   │   │
│   │   ├── middleware/
│   │   │   ├── authenticate.ts        # JWT verification middleware
│   │   │   ├── authorize.ts           # Role-based access middleware
│   │   │   ├── validate.ts            # Zod validation middleware factory
│   │   │   ├── rateLimiter.ts         # Per-route rate limiting
│   │   │   ├── requestLogger.ts       # Winston request logging
│   │   │   ├── requestId.ts           # UUID per request for tracing
│   │   │   └── errorHandler.ts        # Global error handler middleware
│   │   │
│   │   ├── utils/
│   │   │   ├── asyncHandler.ts        # Wrap async route handlers — no try/catch in controllers
│   │   │   ├── pagination.ts          # Pagination helper class
│   │   │   ├── dateUtils.ts           # Date manipulation utilities
│   │   │   └── hashUtils.ts           # bcrypt wrapper
│   │   │
│   │   └── types/
│   │       ├── express.d.ts           # Augment Express Request with user, requestId
│   │       ├── pagination.types.ts    # PaginationOptions, PaginatedResult<T>
│   │       └── common.types.ts        # Shared types across modules
│   │
│   ├── infrastructure/
│   │   ├── cache/
│   │   │   └── UpstashCacheService.ts # Implements ICacheService using Upstash Redis HTTP
│   │   ├── email/
│   │   │   └── ResendEmailService.ts  # Implements IEmailService using Resend SDK
│   │   ├── push/
│   │   │   └── FirebasePushService.ts # Implements IPushService using Firebase Admin
│   │   ├── ai/
│   │   │   └── ClaudeAIService.ts     # Implements IAIService using Anthropic SDK
│   │   └── logger/
│   │       └── WinstonLogger.ts       # Winston singleton with daily rotate
│   │
│   └── modules/
│       ├── auth/
│       │   ├── auth.controller.ts
│       │   ├── auth.service.ts
│       │   ├── auth.repository.ts
│       │   ├── auth.model.ts          # RefreshToken schema
│       │   ├── auth.validator.ts
│       │   ├── auth.routes.ts
│       │   └── auth.types.ts
│       │
│       ├── users/
│       │   ├── users.controller.ts
│       │   ├── users.service.ts
│       │   ├── users.repository.ts
│       │   ├── users.model.ts
│       │   ├── users.validator.ts
│       │   ├── users.routes.ts
│       │   └── users.types.ts
│       │
│       ├── habits/
│       │   ├── habits.controller.ts
│       │   ├── habits.service.ts
│       │   ├── habits.repository.ts
│       │   ├── habits.model.ts
│       │   ├── habits.validator.ts
│       │   ├── habits.routes.ts
│       │   └── habits.types.ts
│       │
│       ├── goals/
│       │   ├── goals.controller.ts
│       │   ├── goals.service.ts
│       │   ├── goals.repository.ts
│       │   ├── goals.model.ts
│       │   ├── goals.validator.ts
│       │   ├── goals.routes.ts
│       │   └── goals.types.ts
│       │
│       ├── journal/
│       │   ├── journal.controller.ts
│       │   ├── journal.service.ts
│       │   ├── journal.repository.ts
│       │   ├── journal.model.ts
│       │   ├── journal.validator.ts
│       │   ├── journal.routes.ts
│       │   └── journal.types.ts
│       │
│       ├── mood/
│       │   ├── mood.controller.ts
│       │   ├── mood.service.ts
│       │   ├── mood.repository.ts
│       │   ├── mood.model.ts
│       │   ├── mood.validator.ts
│       │   ├── mood.routes.ts
│       │   └── mood.types.ts
│       │
│       ├── sleep/
│       │   ├── sleep.controller.ts
│       │   ├── sleep.service.ts
│       │   ├── sleep.repository.ts
│       │   ├── sleep.model.ts
│       │   ├── sleep.validator.ts
│       │   ├── sleep.routes.ts
│       │   └── sleep.types.ts
│       │
│       ├── nutrition/
│       │   ├── nutrition.controller.ts
│       │   ├── nutrition.service.ts
│       │   ├── nutrition.repository.ts
│       │   ├── nutrition.model.ts
│       │   ├── nutrition.validator.ts
│       │   ├── nutrition.routes.ts
│       │   └── nutrition.types.ts
│       │
│       ├── finance/
│       │   ├── finance.controller.ts
│       │   ├── finance.service.ts
│       │   ├── finance.repository.ts
│       │   ├── finance.model.ts
│       │   ├── finance.validator.ts
│       │   ├── finance.routes.ts
│       │   └── finance.types.ts
│       │
│       ├── ai-companion/
│       │   ├── ai-companion.controller.ts
│       │   ├── ai-companion.service.ts
│       │   ├── ai-companion.repository.ts  # Stores AI responses, usage logs
│       │   ├── ai-companion.model.ts
│       │   ├── ai-companion.validator.ts
│       │   ├── ai-companion.routes.ts
│       │   └── ai-companion.types.ts
│       │
│       ├── notifications/
│       │   ├── notifications.controller.ts
│       │   ├── notifications.service.ts
│       │   ├── notifications.repository.ts  # Device tokens, notification history
│       │   ├── notifications.model.ts
│       │   ├── notifications.validator.ts
│       │   ├── notifications.routes.ts
│       │   └── notifications.types.ts
│       │
│       ├── achievements/
│       │   ├── achievements.controller.ts
│       │   ├── achievements.service.ts
│       │   ├── achievements.repository.ts
│       │   ├── achievements.model.ts
│       │   ├── achievements.validator.ts
│       │   ├── achievements.routes.ts
│       │   └── achievements.types.ts
│       │
│       └── subscriptions/
│           ├── subscriptions.controller.ts
│           ├── subscriptions.service.ts
│           ├── subscriptions.repository.ts
│           ├── subscriptions.model.ts
│           ├── subscriptions.validator.ts
│           ├── subscriptions.routes.ts
│           └── subscriptions.types.ts      # [BILLING_WIRE_HERE]
│
├── tests/
│   ├── unit/
│   │   └── modules/
│   │       ├── auth/
│   │       │   ├── auth.service.test.ts
│   │       │   └── auth.repository.test.ts
│   │       └── habits/
│   │           ├── habits.service.test.ts
│   │           └── habits.repository.test.ts
│   ├── integration/
│   │   └── modules/
│   │       ├── auth.routes.test.ts
│   │       └── habits.routes.test.ts
│   └── helpers/
│       ├── testDatabase.ts            # In-memory MongoDB for tests
│       ├── mockFactories.ts           # Factory functions for test data
│       └── mockServices.ts            # Mock implementations of interfaces
│
├── .env.example
├── .env.development
├── .gitignore
├── package.json
├── tsconfig.json
├── jest.config.ts
└── README.md
```

---

## IMPLEMENTATION SPECIFICATIONS

### 1. `src/config/environment.ts`

```typescript
// Validates ALL env vars at startup using Zod.
// If any required var is missing, the app refuses to start with a clear error.
// Exported as a singleton class instance: env.mongoUri, env.jwtSecret, etc.

class Environment {
  readonly nodeEnv: 'development' | 'production' | 'test';
  readonly port: number;
  readonly mongoUri: string;
  readonly jwtSecret: string;
  readonly jwtAccessExpiresIn: string;  // '15m'
  readonly jwtRefreshExpiresIn: string; // '30d'
  readonly upstashRedisRestUrl: string;
  readonly upstashRedisRestToken: string;
  readonly resendApiKey: string;
  readonly resendFromEmail: string;
  readonly firebaseProjectId: string;
  readonly firebaseClientEmail: string;
  readonly firebasePrivateKey: string;
  readonly anthropicApiKey: string;
  readonly frontendUrl: string;
  readonly appName: string;             // 'Velo Life Tracker'
}

export const env = new Environment(); // validated at import time
```

### 2. `src/config/database.ts`

```typescript
// Singleton class. Manages Mongoose connection lifecycle.
// Handles reconnection on drop. Emits events for connected/disconnected.
// Called once in server.ts before app.listen().

class Database {
  private static instance: Database;
  private isConnected: boolean = false;

  static getInstance(): Database { ... }
  async connect(): Promise<void> { ... }
  async disconnect(): Promise<void> { ... }
  getConnectionStatus(): boolean { ... }
}
```

### 3. `src/shared/interfaces/IRepository.ts`

```typescript
// Generic base CRUD interface. All repositories implement this.
// T = the document type. CreateDTO and UpdateDTO are separate types.

interface IRepository<T, CreateDTO, UpdateDTO> {
  findById(id: string): Promise<T | null>;
  findOne(filter: Partial<T>): Promise<T | null>;
  findMany(filter: Partial<T>, options?: PaginationOptions): Promise<PaginatedResult<T>>;
  create(data: CreateDTO): Promise<T>;
  updateById(id: string, data: UpdateDTO): Promise<T | null>;
  deleteById(id: string): Promise<boolean>;
  exists(filter: Partial<T>): Promise<boolean>;
  count(filter: Partial<T>): Promise<number>;
}
```

### 4. `src/shared/base/BaseRepository.ts`

```typescript
// Abstract class. Implements IRepository using a Mongoose Model.
// Subclasses pass their Mongoose model to super().
// Handles all Mongoose-specific error mapping (CastError → ValidationError, etc.).
// Logs all queries in development mode.

abstract class BaseRepository<T, CreateDTO, UpdateDTO>
  implements IRepository<T, CreateDTO, UpdateDTO> {

  constructor(protected readonly model: Model<T>) {}

  async findById(id: string): Promise<T | null> { ... }
  async findOne(filter: Partial<T>): Promise<T | null> { ... }
  async findMany(filter: Partial<T>, options?: PaginationOptions): Promise<PaginatedResult<T>> { ... }
  async create(data: CreateDTO): Promise<T> { ... }
  async updateById(id: string, data: UpdateDTO): Promise<T | null> { ... }
  async deleteById(id: string): Promise<boolean> { ... }
  async exists(filter: Partial<T>): Promise<boolean> { ... }
  async count(filter: Partial<T>): Promise<number> { ... }
}
```

### 5. `src/shared/base/BaseController.ts`

```typescript
// Abstract class with helper methods for consistent responses.
// All controllers extend this. Never use res.json() directly anywhere else.

abstract class BaseController {
  protected sendSuccess<T>(
    res: Response,
    data: T,
    statusCode: number = 200,
    meta?: Partial<ApiResponseMeta>
  ): void { ... }

  protected sendCreated<T>(res: Response, data: T): void { ... }

  protected sendNoContent(res: Response): void { ... }
}
```

### 6. `src/shared/errors/AppError.ts`

```typescript
// Base error class. All custom errors extend this.
// isOperational = true means it is a known error (auth fail, validation).
// isOperational = false means it is a programmer error (bug) — triggers alert.

class AppError extends Error {
  constructor(
    public readonly message: string,
    public readonly statusCode: number,
    public readonly errorCode: string,
    public readonly isOperational: boolean = true,
    public readonly details?: unknown
  ) {
    super(message);
    Object.setPrototypeOf(this, new.target.prototype);
    Error.captureStackTrace(this, this.constructor);
  }
}

// Subclasses — implement all of these:
class ValidationError extends AppError   // 400, 'VALIDATION_ERROR'
class AuthError extends AppError         // 401, 'AUTHENTICATION_ERROR'
class ForbiddenError extends AppError    // 403, 'FORBIDDEN'
class NotFoundError extends AppError     // 404, 'NOT_FOUND'
class ConflictError extends AppError     // 409, 'CONFLICT'
class ExternalServiceError extends AppError // 502, 'EXTERNAL_SERVICE_ERROR'
```

### 7. `src/shared/middleware/errorHandler.ts`

```typescript
// Global Express error handler. Catches all errors thrown in routes.
// Maps AppError subclasses to their HTTP responses.
// Maps Mongoose errors (ValidationError, CastError, duplicate key) to AppError.
// In production: never leak stack traces to client.
// Always returns ApiResponse<never> shape.
// Logs non-operational errors with full stack.
```

### 8. `src/shared/middleware/authenticate.ts`

```typescript
// Verifies JWT access token from Authorization: Bearer <token> header.
// On success: attaches decoded user (id, email, role, tier) to req.user.
// On failure: throws AuthError — caught by global handler.
// Does NOT hit the database — JWT is self-contained.
```

### 9. `src/shared/utils/asyncHandler.ts`

```typescript
// Wraps async route handlers so unhandled rejections go to next(err).
// EVERY async controller method uses this. No try/catch in controllers.

const asyncHandler = (fn: AsyncRequestHandler) =>
  (req: Request, res: Response, next: NextFunction) =>
    Promise.resolve(fn(req, res, next)).catch(next);
```

---

## MODULE IMPLEMENTATION PATTERN

Every module follows this EXACT pattern. Build `auth` and `habits` as the reference modules. All other modules follow the same structure.

### Pattern: auth module (full reference implementation)

#### `auth.types.ts`
```typescript
// All TypeScript types for this module. No logic.
interface IUser {
  _id: ObjectId;
  email: string;
  passwordHash: string;
  name: string;
  role: UserRole;
  tier: UserTier;               // 'free' | 'premium'
  companionStyle: CompanionStyle;
  onboardingComplete: boolean;
  deviceTokens: string[];       // FCM tokens for this user
  createdAt: Date;
  updatedAt: Date;
}

interface IRefreshToken {
  _id: ObjectId;
  userId: ObjectId;
  token: string;                // hashed
  expiresAt: Date;
  userAgent?: string;
  ipAddress?: string;
}

interface RegisterDTO { name: string; email: string; password: string; }
interface LoginDTO { email: string; password: string; }
interface TokenPair { accessToken: string; refreshToken: string; }
interface AuthenticatedUser { id: string; email: string; name: string; role: UserRole; tier: UserTier; }

enum UserRole { USER = 'user', ADMIN = 'admin' }
enum UserTier { FREE = 'free', PREMIUM = 'premium' }
enum CompanionStyle { COACH = 'coach', FRIEND = 'friend', ANALYST = 'analyst', SAGE = 'sage' }
```

#### `auth.model.ts`
```typescript
// Mongoose schema with TypeScript interface. No business logic.
// userSchema: indexes on email (unique). passwordHash pre-save hook NOT here — that is in service.
// refreshTokenSchema: TTL index on expiresAt for automatic cleanup.
```

#### `auth.repository.ts`
```typescript
// Extends BaseRepository. Only MongoDB queries.
// Extra methods beyond CRUD:
//   findByEmail(email: string): Promise<IUser | null>
//   findRefreshToken(hashedToken: string): Promise<IRefreshToken | null>
//   createRefreshToken(data: CreateRefreshTokenDTO): Promise<IRefreshToken>
//   deleteRefreshToken(hashedToken: string): Promise<boolean>
//   deleteAllRefreshTokens(userId: string): Promise<number>  // logout all devices
```

#### `auth.service.ts`
```typescript
// Extends BaseService. Contains ALL business logic for authentication.
// Constructor injects: IUserRepository, ICacheService, logger.
// Methods:
//   register(dto: RegisterDTO): Promise<TokenPair>
//     - check email exists (ConflictError if yes)
//     - hash password with bcrypt (cost 12)
//     - create user
//     - generate token pair
//     - return tokens (never return user object with hash)
//
//   login(dto: LoginDTO): Promise<TokenPair>
//     - find user by email (AuthError if not found — same message as wrong password)
//     - compare password hash (AuthError if wrong — same message)
//     - generate token pair
//
//   refreshTokens(refreshToken: string): Promise<TokenPair>
//     - hash incoming token, find in DB
//     - verify not expired
//     - delete old refresh token (rotation — old token invalid immediately)
//     - generate new token pair
//
//   logout(refreshToken: string): Promise<void>
//     - delete refresh token from DB
//
//   logoutAll(userId: string): Promise<void>
//     - delete all refresh tokens for user
//
// Private methods:
//   generateTokenPair(userId: string, email: string, role: UserRole, tier: UserTier): Promise<TokenPair>
//   hashToken(token: string): string  // SHA256, not bcrypt — for refresh tokens
```

#### `auth.validator.ts`
```typescript
// Zod schemas for all request bodies in this module.
const registerSchema = z.object({
  body: z.object({
    name: z.string().min(2).max(50).trim(),
    email: z.string().email().toLowerCase(),
    password: z.string().min(8).max(128)
      .regex(/[A-Z]/, 'must contain uppercase')
      .regex(/[0-9]/, 'must contain number')
  })
});

const loginSchema = z.object({ body: z.object({ email: ..., password: ... }) });
const refreshSchema = z.object({ body: z.object({ refreshToken: z.string() }) });
```

#### `auth.controller.ts`
```typescript
// Extends BaseController. Zero business logic.
// One method per route. Each uses asyncHandler.
// Calls service, calls this.sendSuccess() or this.sendCreated().

class AuthController extends BaseController {
  constructor(private readonly authService: IAuthService) { super(); }

  register = asyncHandler(async (req: Request, res: Response) => {
    const tokens = await this.authService.register(req.body);
    this.sendCreated(res, tokens);
  });

  login = asyncHandler(async (req: Request, res: Response) => {
    const tokens = await this.authService.login(req.body);
    this.sendSuccess(res, tokens);
  });

  refresh = asyncHandler(async (req: Request, res: Response) => {
    const tokens = await this.authService.refreshTokens(req.body.refreshToken);
    this.sendSuccess(res, tokens);
  });

  logout = asyncHandler(async (req: Request, res: Response) => {
    await this.authService.logout(req.body.refreshToken);
    this.sendNoContent(res);
  });

  me = asyncHandler(async (req: Request, res: Response) => {
    this.sendSuccess(res, req.user);
  });
}
```

#### `auth.routes.ts`
```typescript
// Wires together: validate middleware + controller methods.
// Instantiates repository → service → controller (manual DI, no container needed).
// Exports the Express Router.

const userRepository = new UserRepository();
const cacheService = container.get<ICacheService>('CacheService');
const authService = new AuthService(userRepository, cacheService, logger);
const authController = new AuthController(authService);

router.post('/register', validate(registerSchema), authController.register);
router.post('/login', validate(loginSchema), authController.login);
router.post('/refresh', validate(refreshSchema), authController.refresh);
router.post('/logout', authenticate, authController.logout);
router.get('/me', authenticate, authController.me);

export default router;
```

---

## ALL MODULE API CONTRACTS

Implement every one of these endpoints with full OOP structure.

### Auth — `/api/v1/auth`
```
POST   /register          → { accessToken, refreshToken }
POST   /login             → { accessToken, refreshToken }
POST   /refresh           → { accessToken, refreshToken }
POST   /logout            → 204
POST   /logout-all        → 204
GET    /me                → { id, email, name, role, tier }
```

### Users — `/api/v1/users`
```
GET    /profile           → full user profile + onboarding data
PUT    /profile           → update name, companionStyle, checkinTime, etc.
PUT    /onboarding        → save onboarding answers, mark complete
POST   /device-token      → register FCM device token for push
DELETE /device-token/:token → remove device token
DELETE /account           → soft delete account
```

### Habits — `/api/v1/habits`
```
GET    /                  → paginated list of user's habits
POST   /                  → create new habit { name, icon, frequency, targetDays }
GET    /:id               → single habit with streak data
PUT    /:id               → update habit
DELETE /:id               → delete habit
POST   /:id/log           → log completion for today { note? }
GET    /:id/logs          → paginated log history
GET    /streaks/summary   → all habits with current streak counts
```

### Goals — `/api/v1/goals`
```
GET    /                  → paginated goals list
POST   /                  → create goal { title, description, targetDate, category }
GET    /:id               → goal with progress
PUT    /:id               → update goal
DELETE /:id               → delete goal
PUT    /:id/progress      → update progress { value, note }
POST   /:id/complete      → mark goal complete
```

### Journal — `/api/v1/journal`
```
GET    /                  → paginated journal entries (most recent first)
POST   /                  → create entry { content, mood?, tags? }
GET    /:id               → single entry
PUT    /:id               → update entry
DELETE /:id               → delete entry
GET    /search            → full-text search entries ?q=keyword
```

### Mood — `/api/v1/mood`
```
GET    /                  → paginated mood logs
POST   /                  → log mood { score: 1-10, note?, energy?: 1-10 }
GET    /today             → today's mood log if exists
GET    /weekly-summary    → avg scores for last 7 days per day
GET    /monthly-trends    → monthly aggregation for chart
```

### Sleep — `/api/v1/sleep`
```
GET    /                  → paginated sleep logs
POST   /                  → log sleep { bedtime, wakeTime, quality: 1-5, note? }
GET    /today             → today's sleep log
GET    /weekly-average    → avg duration and quality last 7 days
```

### Nutrition — `/api/v1/nutrition`
```
GET    /                  → paginated meal logs (today first)
POST   /                  → log meal { name, calories, protein?, carbs?, fat?, mealType }
GET    /today             → today's all meals + totals
GET    /weekly-summary    → calorie totals per day last 7 days
```

### Finance — `/api/v1/finance`
```
GET    /goals             → financial goals list
POST   /goals             → create { title, targetAmount, currentAmount, deadline }
PUT    /goals/:id         → update goal
PUT    /goals/:id/contribute → add contribution { amount, note }
GET    /goals/:id/progress → progress with projection
```

### AI Companion — `/api/v1/ai`
```
POST   /onboarding-dashboard → generate personalised dashboard config
                               body: { profile: UserProfile }
                               returns: DashboardConfig (cached 30 days)

POST   /daily-checkin        → get today's check-in
                               body: { streaks, yesterdaySummary, unfiredTriggers }
                               returns: DailyCheckin (cached 23 hours per user)

POST   /feature-impact       → get personalised feature impact sentence
                               body: { featureId, primaryGoal }
                               returns: { impact: string } (cached 7 days)

POST   /conversion-pitch     → get upgrade conversion message
                               body: { triggerId, context }
                               returns: { pitch: string } (no cache — always fresh)

POST   /weekly-report        → get weekly AI report
                               body: { weekData }
                               returns: WeeklyReport (cached 6 days)

POST   /reengagement         → get re-engagement message after absence
                               body: { daysAbsent }
                               returns: { message: string }

GET    /usage                → get AI API usage stats for this user (calls made, cached hits)
```

### Notifications — `/api/v1/notifications`
```
GET    /                  → notification history (paginated)
POST   /send              → [admin only] send push to user
PUT    /:id/read          → mark notification read
PUT    /read-all          → mark all read
GET    /unread-count      → { count: number }
```

### Achievements — `/api/v1/achievements`
```
GET    /                  → all achievements with earned status
GET    /earned            → only earned achievements
GET    /summary           → { totalXp, level, streaks, dayNumber }
POST   /log-activity      → log activity, returns any newly earned badges
                            body: { featureId, xpAmount? }
```

### Subscriptions — `/api/v1/subscriptions`
```
GET    /status            → { tier: 'free'|'premium', expiresAt?, features: [] }
POST   /upgrade           → [BILLING_WIRE_HERE] initiate upgrade
POST   /webhook           → [BILLING_WIRE_HERE] payment provider webhook
POST   /cancel            → [BILLING_WIRE_HERE] cancel subscription
```

---

## MONGODB SCHEMAS — FULL SPECIFICATION

Implement ALL schemas with these exact fields. Add appropriate indexes.

### User
```typescript
{
  email: String (unique, indexed, lowercase),
  passwordHash: String,
  name: String,
  role: enum ['user', 'admin'] default 'user',
  tier: enum ['free', 'premium'] default 'free',
  tierExpiresAt: Date (nullable),
  companionStyle: enum ['coach', 'friend', 'analyst', 'sage'],
  primaryGoal: String,
  experienceLevel: enum ['just_starting', 'few_months', 'over_a_year'],
  dailyCommitmentMinutes: enum [10, 30, 60],
  selectedFeatures: [String],
  checkinTime: enum ['morning', 'midday', 'evening', 'varies'],
  motivationStyle: enum ['streaks', 'milestones', 'daily_progress', 'accountability'],
  onboardingComplete: Boolean default false,
  deviceTokens: [String],  // FCM tokens
  lastActiveAt: Date,
  firstLoginAt: Date,
  createdAt: Date,
  updatedAt: Date
}
// Indexes: email (unique), tier, lastActiveAt
```

### Habit
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  name: String,
  description: String (optional),
  icon: String,
  color: String,
  frequency: enum ['daily', 'weekly', 'custom'],
  targetDaysPerWeek: Number (1-7),
  currentStreak: Number default 0,
  longestStreak: Number default 0,
  totalCompletions: Number default 0,
  lastCompletedAt: Date,
  isActive: Boolean default true,
  tier: enum ['free', 'premium'] default 'free',
  createdAt: Date,
  updatedAt: Date
}
// Indexes: userId, userId + isActive, userId + currentStreak
```

### HabitLog
```typescript
{
  habitId: ObjectId (ref: 'Habit', indexed),
  userId: ObjectId (ref: 'User', indexed),
  completedAt: Date,
  dateKey: String,  // 'YYYY-MM-DD' for deduplication
  note: String (optional),
  createdAt: Date
}
// Indexes: habitId + dateKey (unique compound), userId + completedAt
```

### Goal
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  title: String,
  description: String,
  category: enum ['fitness', 'career', 'finance', 'health', 'personal', 'other'],
  targetDate: Date,
  progressValue: Number default 0,  // 0-100 percentage
  isCompleted: Boolean default false,
  completedAt: Date,
  milestones: [{ title: String, completedAt: Date, order: Number }],
  tier: enum ['free', 'premium'] default 'free',
  createdAt: Date,
  updatedAt: Date
}
```

### JournalEntry
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  content: String,
  mood: Number (1-10, optional),
  tags: [String],
  wordCount: Number,
  aiAnalyzed: Boolean default false,  // premium feature flag
  tier: enum ['free', 'premium'] default 'free',
  createdAt: Date,
  updatedAt: Date
}
// Indexes: userId + createdAt, text index on content for search
```

### MoodLog
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  score: Number (1-10),
  energy: Number (1-10, optional),
  note: String (optional),
  dateKey: String,  // 'YYYY-MM-DD'
  loggedAt: Date,
  createdAt: Date
}
// Indexes: userId + dateKey (unique compound), userId + loggedAt
```

### SleepLog
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  bedtime: Date,
  wakeTime: Date,
  durationMinutes: Number,  // computed: wakeTime - bedtime
  quality: Number (1-5),
  note: String (optional),
  dateKey: String,
  createdAt: Date
}
// Indexes: userId + dateKey (unique compound)
```

### NutritionLog
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  name: String,
  calories: Number,
  protein: Number (optional),
  carbs: Number (optional),
  fat: Number (optional),
  mealType: enum ['breakfast', 'lunch', 'dinner', 'snack'],
  dateKey: String,
  loggedAt: Date,
  createdAt: Date
}
// Indexes: userId + dateKey, userId + loggedAt
```

### FinanceGoal
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  title: String,
  targetAmount: Number,
  currentAmount: Number default 0,
  currency: String default 'GBP',
  deadline: Date,
  contributions: [{ amount: Number, note: String, date: Date }],
  isCompleted: Boolean default false,
  completedAt: Date,
  createdAt: Date,
  updatedAt: Date
}
```

### AILog
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  requestType: enum ['onboarding_dashboard', 'daily_checkin', 'feature_impact',
                      'conversion_pitch', 'weekly_report', 'reengagement'],
  prompt: String,
  response: String,
  model: String,
  tokensUsed: Number,
  latencyMs: Number,
  fromCache: Boolean,
  cacheKey: String,
  createdAt: Date
}
// Indexes: userId + requestType + createdAt
// Purpose: usage analytics, debugging, cost tracking
```

### Notification
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  title: String,
  body: String,
  type: enum ['streak_milestone', 'daily_checkin', 'goal_achieved',
              'conversion_trigger', 'reengagement', 'badge_earned'],
  data: Mixed,  // extra payload for deep linking
  isRead: Boolean default false,
  sentAt: Date,
  readAt: Date,
  createdAt: Date
}
// Indexes: userId + isRead, userId + createdAt
```

### Achievement
```typescript
{
  userId: ObjectId (ref: 'User', indexed),
  badgeId: String,  // matches BADGE_DEFINITIONS ids
  earnedAt: Date,
  xpAwarded: Number,
  createdAt: Date
}
// Indexes: userId, userId + badgeId (unique compound)
```

### Subscription
```typescript
{
  userId: ObjectId (ref: 'User', unique),
  tier: enum ['free', 'premium'],
  status: enum ['active', 'cancelled', 'expired', 'trial'],
  trialEndsAt: Date,
  currentPeriodStart: Date,
  currentPeriodEnd: Date,
  cancelledAt: Date,
  // [BILLING_WIRE_HERE] — add provider fields here
  providerName: String,     // 'stripe', 'google_play' etc
  providerSubscriptionId: String,
  createdAt: Date,
  updatedAt: Date
}
```

---

## INFRASTRUCTURE IMPLEMENTATIONS

### `UpstashCacheService.ts`

```typescript
// Implements ICacheService using Upstash Redis HTTP API (no TCP connection needed).
// Works on Render free tier and any serverless environment.
// Methods: get<T>, set<T> with TTL, del, flush
// Key format: 'velo:{module}:{userId}:{identifier}'
// All values JSON serialized/deserialized.
// get() returns null on cache miss — never throws on miss.
// All errors wrapped in ExternalServiceError.
```

### `ClaudeAIService.ts`

```typescript
// Implements IAIService using @anthropic-ai/sdk.
// Model: always 'claude-sonnet-4-6', max_tokens: 1000.
// CRITICAL: check cache BEFORE calling API. Write to cache AFTER.
// Cache TTLs:
//   onboarding_dashboard: 30 * 24 * 60 * 60  (30 days)
//   daily_checkin:        23 * 60 * 60         (23 hours)
//   feature_impact:        7 * 24 * 60 * 60   (7 days)
//   conversion_pitch:      0                  (no cache)
//   weekly_report:         6 * 24 * 60 * 60   (6 days)
//   reengagement:          0                  (no cache)
//
// All API calls logged to AILog collection.
// JSON response parsing: strip ```json and ``` fences before JSON.parse().
// Every method has a typed fallback — if parsing fails, return the fallback, never throw.
// Retry logic: 2 retries with exponential backoff (1s, 2s) for 429 and 5xx errors.
```

### `FirebasePushService.ts`

```typescript
// Implements IPushService using firebase-admin.
// Initializes Firebase Admin SDK once (singleton pattern).
// sendToUser(userId, notification): fetches user's deviceTokens, sends to all.
// sendToToken(token, notification): sends to specific device.
// Handles invalid token errors — removes stale tokens from user's deviceTokens array.
// Never throws if push fails — logs error and continues.
```

### `ResendEmailService.ts`

```typescript
// Implements IEmailService using 'resend' npm package.
// sendEmail(to, subject, htmlBody, textBody?): Promise<void>
// All emails use env.resendFromEmail as sender.
// Email templates are plain strings in this service for now.
// Wrap in try/catch — email failure should never crash an API request.
```

---

## SECURITY REQUIREMENTS

Every one of these must be implemented:

1. **Helmet.js** — sets all security headers
2. **CORS** — whitelist only `env.frontendUrl` and `localhost:4200` in development
3. **Rate limiting** — global: 100 req/min per IP. Auth routes: 5 req/min per IP. AI routes: 20 req/min per user.
4. **JWT refresh token rotation** — old refresh token invalidated on every refresh call
5. **Refresh token hashing** — stored as SHA256 hash in DB, never plain text
6. **Password hashing** — bcrypt cost factor 12
7. **Request ID** — UUID attached to every request, included in all log lines and error responses
8. **Input sanitization** — Zod strips unknown fields on all request bodies
9. **MongoDB injection prevention** — Mongoose handles this; never use `$where` or `eval`
10. **Sensitive data never in logs** — passwords, tokens, full JWT never logged

---

## LOGGING STANDARD

Every log line must include: `{ level, message, requestId, userId?, module, timestamp, ...context }`

```typescript
// Usage in every service:
this.logger.info('Habit created', { requestId, userId, habitId: habit._id });
this.logger.error('MongoDB query failed', { requestId, error: err.message, query });
this.logger.warn('AI cache miss — calling API', { requestId, userId, requestType });
```

Log levels:
- `error` — operational errors and all caught exceptions
- `warn` — cache misses, deprecated usage, approaching limits
- `info` — successful operations, key business events
- `debug` — development only, verbose query logging

---

## GOOGLE SHEETS MIGRATION

The existing frontend may have data in Google Sheets. Handle this:

1. **Do not write a migration script yet** — the Angular frontend will call the new API going forward
2. **Create a `POST /api/v1/migration/import` endpoint** — accepts a JSON payload matching the old Google Sheets structure, maps it to MongoDB documents, imports for the authenticated user
3. **Google Apps Script backend** — the old backend is completely replaced. Remove all Google Sheets SDK code. The Angular frontend's `environment.ts` API URL will point to the new Node.js backend.
4. **Data mapping guide** — document in `README.md` how each Google Sheet column maps to a MongoDB field

---

## `package.json` — exact dependencies

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "@anthropic-ai/sdk": "^0.24.0",
    "mongoose": "^8.0.0",
    "jsonwebtoken": "^9.0.2",
    "bcrypt": "^5.1.1",
    "zod": "^3.22.4",
    "winston": "^3.11.0",
    "winston-daily-rotate-file": "^4.7.1",
    "helmet": "^7.1.0",
    "cors": "^2.8.5",
    "express-rate-limit": "^7.1.5",
    "resend": "^3.2.0",
    "firebase-admin": "^12.0.0",
    "@upstash/redis": "^1.28.0",
    "uuid": "^9.0.1",
    "date-fns": "^3.0.6"
  },
  "devDependencies": {
    "typescript": "^5.3.3",
    "@types/express": "^4.17.21",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/bcrypt": "^5.0.2",
    "@types/cors": "^2.8.17",
    "@types/uuid": "^9.0.7",
    "@types/node": "^20.10.0",
    "ts-node": "^10.9.2",
    "nodemon": "^3.0.2",
    "jest": "^29.7.0",
    "@types/jest": "^29.5.11",
    "ts-jest": "^29.1.1",
    "supertest": "^6.3.4",
    "@types/supertest": "^6.0.2",
    "mongodb-memory-server": "^9.1.6",
    "eslint": "^8.56.0",
    "@typescript-eslint/eslint-plugin": "^6.17.0",
    "@typescript-eslint/parser": "^6.17.0"
  }
}
```

---

## `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "CommonJS",
    "lib": ["ES2022"],
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noImplicitReturns": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "experimentalDecorators": false,
    "resolveJsonModule": true,
    "baseUrl": ".",
    "paths": {
      "@shared/*": ["src/shared/*"],
      "@modules/*": ["src/modules/*"],
      "@config/*": ["src/config/*"],
      "@infrastructure/*": ["src/infrastructure/*"]
    }
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist", "tests"]
}
```

---

## ANDROID APP SETUP (Capacitor)

After building the backend, add Android support to the existing Angular app:

```bash
# In the Angular project root:
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android
npm install @capacitor/push-notifications  # FCM integration
npm install @capacitor/app                  # App lifecycle
npm install @capacitor/network              # Online/offline detection
npm install @capacitor/splash-screen
npm install @capacitor/status-bar

npx cap init "Velo Life Tracker" "com.velo.lifetracker" --web-dir=dist/velo-app
npx cap add android
```

Create `capacitor.config.ts`:
```typescript
const config: CapacitorConfig = {
  appId: 'com.velo.lifetracker',
  appName: 'Velo Life Tracker',
  webDir: 'dist/velo-app',
  server: {
    androidScheme: 'https',
    cleartext: false
  },
  plugins: {
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert']
    },
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#1a1a2e',
      showSpinner: false
    }
  }
};
```

Create `src/app/core/services/push-notification.service.ts` in the Angular project:
```typescript
// Angular service that wraps @capacitor/push-notifications.
// On app init: requests permission, gets FCM token, sends token to POST /api/v1/users/device-token.
// Listens for push notifications, dispatches to Angular notification store.
// Handles token refresh — sends new token to API when FCM rotates it.
```

---

## BUILD ORDER — IMPLEMENT IN EXACTLY THIS SEQUENCE

1. Project scaffolding — `package.json`, `tsconfig.json`, folder structure, `.env.example`
2. `config/environment.ts` — Zod validation of all env vars
3. `config/database.ts` — MongoDB singleton connection
4. `shared/errors/` — All error classes
5. `shared/interfaces/` — All interfaces
6. `shared/base/` — BaseRepository, BaseService, BaseController
7. `shared/middleware/` — errorHandler, asyncHandler, authenticate, validate, requestId, requestLogger, rateLimiter
8. `shared/utils/` — all utility functions
9. `infrastructure/logger/` — WinstonLogger
10. `infrastructure/cache/` — UpstashCacheService
11. `infrastructure/ai/` — ClaudeAIService
12. `infrastructure/push/` — FirebasePushService
13. `infrastructure/email/` — ResendEmailService
14. `src/app.ts` — Express app factory with all middleware
15. `src/server.ts` — entry point
16. **Module: auth** — complete reference implementation (types → model → repository → service → validator → controller → routes)
17. **Module: users** — follows auth pattern exactly
18. **Module: habits** — with HabitLog sub-collection
19. **Module: goals**
20. **Module: journal**
21. **Module: mood**
22. **Module: sleep**
23. **Module: nutrition**
24. **Module: finance**
25. **Module: ai-companion** — wires ClaudeAIService with full caching
26. **Module: notifications** — wires FirebasePushService
27. **Module: achievements** — XP, badges, level calculation
28. **Module: subscriptions** — placeholder with [BILLING_WIRE_HERE] comments
29. Wire all module routes into `app.ts`
30. Unit tests for auth and habits (service + repository)
31. Integration tests for auth and habits routes
32. Capacitor Android setup in Angular project
33. Push notification Angular service
34. `README.md` with full setup guide, env vars table, Google Sheets migration map

---

## FINAL QUALITY CHECKLIST

Before finishing, verify every item:

- [ ] `tsc --noEmit` passes with zero errors
- [ ] ESLint passes with zero warnings
- [ ] No `any` types anywhere in the codebase
- [ ] Every async function uses `asyncHandler` wrapper
- [ ] Every error thrown is an `AppError` subclass
- [ ] Every external service call is wrapped in try/catch that throws `ExternalServiceError`
- [ ] Every MongoDB model has appropriate indexes defined
- [ ] All env vars are in `.env.example` with placeholder values and comments
- [ ] JWT secrets are minimum 32 characters in example
- [ ] Rate limiting applied to all auth and AI routes
- [ ] `req.user` is always typed — never `any`
- [ ] All `console.log` replaced with `logger.*`
- [ ] No hardcoded strings — all in `constants.ts` or `environment.ts`
- [ ] Refresh token rotation implemented — old token deleted on refresh
- [ ] AI responses always have typed fallbacks — never throw on parse error
- [ ] Push notification failures are logged but never propagate to caller
- [ ] `[BILLING_WIRE_HERE]` comments present in subscriptions module
- [ ] `[GOOGLE_SHEETS_MIGRATION]` comments on migration endpoint
- [ ] README documents every env var and its purpose

---

## SECURITY MODULE — COMPLETE ATTACK PREVENTION SPECIFICATION

This section is non-negotiable. Every item must be implemented. Security is not a feature to add later — it is built into every layer from day one.

---

### ATTACK 1 — BRUTE FORCE & CREDENTIAL STUFFING

**Threat:** Attacker makes thousands of login attempts to guess passwords or test stolen credentials.

**Implementation — `src/shared/middleware/rateLimiter.ts`**

```typescript
import rateLimit from 'express-rate-limit';
import { Request, Response } from 'express';
import { TooManyRequestsError } from '../errors/TooManyRequestsError';

// Factory function — creates limiters with different configs per route
export class RateLimiterFactory {

  static createGlobalLimiter() {
    return rateLimit({
      windowMs: 60 * 1000,         // 1 minute window
      max: 100,                     // 100 requests per IP per window
      standardHeaders: true,
      legacyHeaders: false,
      skipSuccessfulRequests: false,
      handler: (req: Request, res: Response) => {
        throw new TooManyRequestsError('Too many requests. Slow down.');
      }
    });
  }

  static createAuthLimiter() {
    return rateLimit({
      windowMs: 15 * 60 * 1000,    // 15 minute window
      max: 10,                      // 10 attempts per IP
      skipSuccessfulRequests: true, // only count failed attempts
      handler: (req: Request, res: Response) => {
        SecurityLogger.logEvent('BRUTE_FORCE_BLOCKED', req);
        throw new TooManyRequestsError('Too many login attempts. Try again in 15 minutes.');
      }
    });
  }

  static createAILimiter() {
    return rateLimit({
      windowMs: 60 * 1000,
      max: 20,                      // AI calls are expensive — limit per user not IP
      keyGenerator: (req: Request) => req.user?.id || req.ip,
      handler: (req: Request, res: Response) => {
        throw new TooManyRequestsError('AI request limit reached. Try again shortly.');
      }
    });
  }

  static createPasswordResetLimiter() {
    return rateLimit({
      windowMs: 60 * 60 * 1000,    // 1 hour window
      max: 3,                       // 3 password reset attempts per hour
      handler: (req: Request, res: Response) => {
        SecurityLogger.logEvent('PASSWORD_RESET_BLOCKED', req);
        throw new TooManyRequestsError('Too many password reset attempts.');
      }
    });
  }
}
```

**Account lockout — add to `AuthService`:**
```typescript
// Track failed attempts per email in Redis with TTL
// After 10 failures: lock account for 30 minutes
// On successful login: reset failure counter
// lockout key: 'auth:lockout:{email}'
// failure key:  'auth:failures:{email}'
```

---

### ATTACK 2 — JWT TOKEN THEFT & REPLAY

**Threat:** Attacker steals an access token from local storage or a network intercept and reuses it indefinitely.

**Implementation — `src/modules/auth/auth.service.ts` — token strategy:**

```typescript
// ACCESS TOKEN: short-lived (15 minutes), stateless JWT
// Payload: { sub: userId, email, role, tier, iat, exp }
// NEVER include: password, sensitive data, full user object

// REFRESH TOKEN: long-lived (30 days), stored in DB as SHA-256 hash
// Rotation: every refresh call issues a NEW refresh token and invalidates the old one
// Token family detection: if a rotated (already-used) refresh token is presented,
//   treat as token theft — invalidate ALL refresh tokens for that user immediately

private generateTokenPair(user: IUser): TokenPair {
  const accessToken = jwt.sign(
    { sub: user._id.toString(), email: user.email, role: user.role, tier: user.tier },
    env.jwtSecret,
    { expiresIn: '15m', issuer: 'velo-api', audience: 'velo-client' }
  );

  const rawRefreshToken = crypto.randomBytes(64).toString('hex');
  const hashedRefreshToken = this.hashToken(rawRefreshToken);
  // Store hashedRefreshToken in DB — return rawRefreshToken to client
  return { accessToken, refreshToken: rawRefreshToken };
}

// On refresh: detect reuse attack
async refreshTokens(rawToken: string): Promise<TokenPair> {
  const hash = this.hashToken(rawToken);
  const stored = await this.refreshTokenRepo.findByHash(hash);

  if (!stored) {
    // Token not found — possible theft of already-rotated token
    // Find if this hash was recently deleted → if yes, revoke all tokens for that user
    await this.revokeAllUserTokens(stored?.userId); // nuclear option
    SecurityLogger.logEvent('REFRESH_TOKEN_REUSE_DETECTED', { hash });
    throw new AuthError('Invalid refresh token. All sessions terminated for security.');
  }

  if (stored.expiresAt < new Date()) {
    await this.refreshTokenRepo.deleteByHash(hash);
    throw new AuthError('Refresh token expired. Please log in again.');
  }

  // Rotate: delete old, create new
  await this.refreshTokenRepo.deleteByHash(hash);
  return this.generateTokenPair(await this.userRepo.findById(stored.userId));
}

private hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}
```

---

### ATTACK 3 — NOSQL INJECTION

**Threat:** Attacker sends `{ "email": { "$gt": "" }, "password": { "$gt": "" } }` in request body to bypass authentication.

**Implementation — two layers:**

**Layer 1 — `express-mongo-sanitize` middleware (add to `app.ts`):**
```typescript
import mongoSanitize from 'express-mongo-sanitize';

// Strips keys that start with $ or contain . from req.body, req.params, req.query
app.use(mongoSanitize({
  replaceWith: '_',        // replace operators with underscore instead of removing
  onSanitizeError: (req, res, next, err) => {
    SecurityLogger.logEvent('NOSQL_INJECTION_ATTEMPT', req);
    throw new ValidationError('Invalid characters in request');
  }
}));
```

**Layer 2 — Zod strips all unknown fields (already in place). Never use `req.body` directly in a Mongoose query. Always destructure validated fields:**
```typescript
// WRONG — never do this:
await UserModel.findOne(req.body);

// CORRECT — always:
const { email } = registerSchema.parse(req.body); // Zod validated
await this.userRepository.findByEmail(email);      // typed parameter
```

**Additional — add to `BaseRepository`:**
```typescript
// Validate that ID params are valid MongoDB ObjectIds before querying
private validateObjectId(id: string): void {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ValidationError(`Invalid ID format: ${id}`);
  }
}
```

---

### ATTACK 4 — XSS (CROSS-SITE SCRIPTING)

**Threat:** Attacker stores `<script>alert(document.cookie)</script>` in a habit name or journal entry. When rendered, it executes in another user's browser.

**Implementation — three layers:**

**Layer 1 — Helmet security headers (add to `app.ts`):**
```typescript
import helmet from 'helmet';

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"],
      frameSrc: ["'none'"],
      objectSrc: ["'none'"],
    }
  },
  hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
  noSniff: true,
  xssFilter: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
}));
```

**Layer 2 — `xss-clean` on all text inputs:**
```typescript
import xss from 'xss-clean';
app.use(xss()); // sanitises req.body, req.query, req.params
```

**Layer 3 — Zod string length limits prevent payload bloat:**
```typescript
// In all validators — all free-text fields have max length
content: z.string().max(10000).trim(),  // journal
name:    z.string().max(100).trim(),     // habit name
note:    z.string().max(500).trim(),     // log note
```

---

### ATTACK 5 — CSRF (CROSS-SITE REQUEST FORGERY)

**Threat:** Malicious site tricks logged-in user's browser into making a request to the API using their credentials.

**Why this is already mitigated for Velo:** The API uses JWT in Authorization header (not cookies), so browser-automatic credential sending doesn't apply. However, implement defence-in-depth:

```typescript
// In CORS config — whitelist only known origins
app.use(cors({
  origin: (origin, callback) => {
    const allowed = [env.frontendUrl, 'http://localhost:4200'];
    if (!origin || allowed.includes(origin)) {
      callback(null, true);
    } else {
      SecurityLogger.logEvent('CORS_BLOCKED', { origin });
      callback(new ForbiddenError(`Origin ${origin} not allowed`));
    }
  },
  credentials: false,              // No cookies used — credentials: false
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
  exposedHeaders: ['X-Request-ID'],
  maxAge: 86400                    // Cache preflight for 24 hours
}));
```

---

### ATTACK 6 — DDOS & VOLUMETRIC FLOOD

**Threat:** Attacker sends millions of requests to exhaust server resources or bandwidth.

**Layer 1 — Cloudflare Workers gateway (first line of defence — before traffic reaches Node.js):**
```typescript
// In your Cloudflare Worker:
// - Global rate limit: 100 req/min per IP
// - Bot detection via cf-threat-score
// - Block countries if needed via cf.country
// - Cache GET responses where possible (reduce origin hits)
// - Request size validation before forwarding
```

**Layer 2 — Express body size limits (in `app.ts`):**
```typescript
app.use(express.json({ limit: '10kb' }));    // JSON body cap
app.use(express.urlencoded({ limit: '10kb', extended: true }));

// Reject requests with no Content-Type on POST/PUT
app.use((req, res, next) => {
  if (['POST', 'PUT', 'PATCH'].includes(req.method) && !req.headers['content-type']) {
    throw new ValidationError('Content-Type header required');
  }
  next();
});
```

**Layer 3 — Slow-down middleware for repeated requests:**
```typescript
import slowDown from 'express-slow-down';

export const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000,
  delayAfter: 50,              // allow 50 req/15min at full speed
  delayMs: (used) => (used - 50) * 100,  // +100ms delay per request above limit
  maxDelayMs: 5000             // cap at 5 second delay
});
```

---

### ATTACK 7 — BOLA / IDOR (BROKEN OBJECT LEVEL AUTHORISATION)

**Threat:** User A calls `GET /api/v1/habits/[user_B_habit_id]` and reads another user's private data.

**This is the most common API vulnerability. Enforce at repository level — never rely on callers to filter:**

**Implementation — `src/shared/base/BaseRepository.ts` ownership enforcement:**
```typescript
// ALL findById operations that involve user-owned resources MUST include userId
// Override in every module repository — never use the base findById without userId scope

// In HabitsRepository:
async findByIdForUser(id: string, userId: string): Promise<IHabit | null> {
  this.validateObjectId(id);
  return this.model.findOne({ _id: id, userId }).exec();
  // If userId doesn't match, returns null → service throws NotFoundError
  // Attacker gets 404, not the data and not a 403 that reveals existence
}

// Rule: 404 for unauthorised resource access, never 403
// Reason: 403 tells attacker the resource EXISTS but they can't access it
//         404 reveals nothing about other users' data
```

**Implementation — ownership middleware factory:**
```typescript
// src/shared/middleware/ownershipGuard.ts
// Usage: router.get('/:id', authenticate, ownershipGuard(HabitRepository), controller.getById)

export const ownershipGuard = (Repository: typeof BaseRepository) =>
  asyncHandler(async (req: Request, res: Response, next: NextFunction) => {
    const resource = await new Repository().findByIdForUser(req.params.id, req.user.id);
    if (!resource) throw new NotFoundError(`Resource not found`);
    req.resource = resource; // attach to request for controller
    next();
  });
```

---

### ATTACK 8 — MASS ASSIGNMENT

**Threat:** User sends `{ "role": "admin", "tier": "premium" }` in a profile update body and gains elevated privileges.

**Rule: Zod schemas are the ONLY thing that defines what fields are accepted. If it is not in the schema, it does not exist.**

```typescript
// users.validator.ts — profile update schema
// ONLY these fields are permitted in a user update:
const updateProfileSchema = z.object({
  body: z.object({
    name:             z.string().min(2).max(50).trim().optional(),
    companionStyle:   z.enum(['coach', 'friend', 'analyst', 'sage']).optional(),
    checkinTime:      z.enum(['morning', 'midday', 'evening', 'varies']).optional(),
    motivationStyle:  z.enum(['streaks', 'milestones', 'daily_progress', 'accountability']).optional(),
    // NEVER: role, tier, passwordHash, deviceTokens, firstLoginAt, _id
  }).strict()  // .strict() rejects any unknown keys with a ZodError — CRITICAL
});

// In UserRepository.updateById — never use spread of request body:
// WRONG:
await UserModel.findByIdAndUpdate(id, req.body);

// CORRECT — only pass the DTO which was validated and typed:
async updateProfile(id: string, dto: UpdateProfileDTO): Promise<IUser | null> {
  return this.model.findByIdAndUpdate(
    id,
    { $set: { name: dto.name, companionStyle: dto.companionStyle } }, // explicit fields
    { new: true, runValidators: true }
  ).select('-passwordHash').exec();
}
```

---

### ATTACK 9 — SECURITY EVENT LOGGING & ANOMALY DETECTION

**Threat:** Attacks go undetected because there is no audit trail. No forensic data after a breach.

**Implementation — `src/infrastructure/security/SecurityLogger.ts`:**

```typescript
export enum SecurityEventType {
  LOGIN_SUCCESS           = 'LOGIN_SUCCESS',
  LOGIN_FAILURE           = 'LOGIN_FAILURE',
  BRUTE_FORCE_BLOCKED     = 'BRUTE_FORCE_BLOCKED',
  ACCOUNT_LOCKED          = 'ACCOUNT_LOCKED',
  REFRESH_TOKEN_REUSE     = 'REFRESH_TOKEN_REUSE_DETECTED',
  NOSQL_INJECTION_ATTEMPT = 'NOSQL_INJECTION_ATTEMPT',
  CORS_BLOCKED            = 'CORS_BLOCKED',
  RATE_LIMIT_EXCEEDED     = 'RATE_LIMIT_EXCEEDED',
  INVALID_TOKEN           = 'INVALID_TOKEN',
  FORBIDDEN_ACCESS        = 'FORBIDDEN_ACCESS',
  SUSPICIOUS_PAYLOAD      = 'SUSPICIOUS_PAYLOAD',
  PASSWORD_RESET_REQUESTED = 'PASSWORD_RESET_REQUESTED',
  ACCOUNT_DELETED         = 'ACCOUNT_DELETED',
  ADMIN_ACTION            = 'ADMIN_ACTION',
}

export class SecurityLogger {
  private static logger = WinstonLogger.getInstance();

  static logEvent(
    event: SecurityEventType,
    req: Request,
    extra?: Record<string, unknown>
  ): void {
    // Log structure that can be parsed by BetterStack/Datadog for alerting
    this.logger.warn(`SECURITY_EVENT: ${event}`, {
      securityEvent: event,
      ip:            req.ip,
      requestId:     req.requestId,
      userId:        req.user?.id ?? 'anonymous',
      userAgent:     req.headers['user-agent'],
      path:          req.path,
      method:        req.method,
      timestamp:     new Date().toISOString(),
      ...extra
    });

    // Critical events trigger immediate alert (wire to BetterStack later)
    const criticalEvents = [
      SecurityEventType.REFRESH_TOKEN_REUSE,
      SecurityEventType.NOSQL_INJECTION_ATTEMPT,
      SecurityEventType.BRUTE_FORCE_BLOCKED
    ];
    if (criticalEvents.includes(event)) {
      this.triggerAlert(event, req);
    }
  }

  private static triggerAlert(event: SecurityEventType, req: Request): void {
    // [ALERT_WIRE_HERE] — connect to BetterStack, PagerDuty, or email
    // For now: log at error level so it appears in BetterStack error stream
    this.logger.error(`CRITICAL SECURITY EVENT: ${event}`, { ip: req.ip });
  }
}
```

---

### ATTACK 10 — RÉDOS & OVERSIZED PAYLOADS

**Threat:** Attacker sends a crafted string that causes catastrophic backtracking in a regex, or a 100MB JSON body that OOMs the process.

```typescript
// src/shared/utils/safeRegex.ts
import safeRegex from 'safe-regex';

// Validate any developer-written regex before use — run in tests
export function assertSafeRegex(pattern: RegExp): void {
  if (!safeRegex(pattern)) {
    throw new Error(`Unsafe regex detected: ${pattern} — vulnerable to ReDoS`);
  }
}

// In ALL Zod validators — every string field has max length:
// name fields:    max(100)
// description:   max(500)
// content/notes: max(10000)
// search query:  max(200)
// email:         max(254)   — RFC 5321 limit
// password:      max(128)   — prevents bcrypt timing attacks on very long inputs
```

---

### ATTACK 11 — PARAMETER POLLUTION (HPP)

**Threat:** Attacker sends `?sort=name&sort=__proto__` to override query parameters or pollute the prototype chain.

```typescript
import hpp from 'hpp';

// Add to app.ts after body parsers:
app.use(hpp({
  whitelist: ['tags', 'features']  // allow arrays only for these known array params
}));
```

---

### ATTACK 12 — PATH TRAVERSAL

**Threat:** Attacker sends `../../etc/passwd` as a file path parameter to read system files.

```typescript
// In any endpoint that accepts file paths or IDs:
// 1. Always validate IDs are valid MongoDB ObjectIds (already in BaseRepository)
// 2. Never use req.params values directly in file system operations
// 3. For Cloudflare R2 uploads — validate file type by magic bytes, not extension:

export class FileValidator {
  private static readonly ALLOWED_MIME_TYPES = [
    'image/jpeg', 'image/png', 'image/webp'
  ];

  static validate(buffer: Buffer, declaredMimeType: string): void {
    // Check magic bytes — first 4 bytes identify file type
    const magicBytes = buffer.slice(0, 4).toString('hex');
    const isJpeg = magicBytes.startsWith('ffd8ff');
    const isPng  = magicBytes.startsWith('89504e47');
    const isWebp = buffer.slice(0, 12).toString('ascii').includes('WEBP');

    if (!isJpeg && !isPng && !isWebp) {
      throw new ValidationError('Invalid file type. Only images allowed.');
    }
    if (!this.ALLOWED_MIME_TYPES.includes(declaredMimeType)) {
      throw new ValidationError('Unsupported MIME type.');
    }
  }
}
```

---

### SECURITY HEADERS — COMPLETE `app.ts` SETUP

```typescript
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import mongoSanitize from 'express-mongo-sanitize';
import xss from 'xss-clean';
import hpp from 'hpp';
import slowDown from 'express-slow-down';
import compression from 'compression';

export function createApp(): express.Application {
  const app = express();

  // ── 1. Trust proxy (needed for correct IP behind Cloudflare/Render) ──
  app.set('trust proxy', 1);

  // ── 2. Security headers ──────────────────────────────────────────────
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc:  ["'self'"],
        scriptSrc:   ["'self'"],
        styleSrc:    ["'self'", "'unsafe-inline'"],
        imgSrc:      ["'self'", "data:", "https:"],
        connectSrc:  ["'self'"],
        frameSrc:    ["'none'"],
        objectSrc:   ["'none'"],
        upgradeInsecureRequests: [],
      }
    },
    hsts:            { maxAge: 31536000, includeSubDomains: true, preload: true },
    noSniff:         true,
    xssFilter:       true,
    hidePoweredBy:   true,  // removes X-Powered-By: Express
    referrerPolicy:  { policy: 'strict-origin-when-cross-origin' },
    crossOriginEmbedderPolicy: true,
    crossOriginOpenerPolicy:   { policy: 'same-origin' },
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  }));

  // ── 3. CORS ──────────────────────────────────────────────────────────
  app.use(cors({
    origin: (origin, cb) => {
      const allowed = [env.frontendUrl, 'http://localhost:4200'];
      if (!origin || allowed.includes(origin)) return cb(null, true);
      SecurityLogger.logEvent('CORS_BLOCKED', { origin } as any);
      cb(new ForbiddenError('CORS policy violation'));
    },
    credentials: false,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID'],
    exposedHeaders: ['X-Request-ID', 'X-RateLimit-Limit', 'X-RateLimit-Remaining'],
    maxAge: 86400,
  }));

  // ── 4. Request ID (before loggers) ───────────────────────────────────
  app.use(requestIdMiddleware);

  // ── 5. Request logging ───────────────────────────────────────────────
  app.use(requestLoggerMiddleware);

  // ── 6. Body parsing with size limits ─────────────────────────────────
  app.use(express.json({ limit: '10kb' }));
  app.use(express.urlencoded({ limit: '10kb', extended: true }));

  // ── 7. Injection prevention ──────────────────────────────────────────
  app.use(mongoSanitize({ replaceWith: '_' }));
  app.use(xss());
  app.use(hpp({ whitelist: ['tags', 'features'] }));

  // ── 8. Speed limiter (soft DDoS protection) ──────────────────────────
  app.use(slowDown({
    windowMs: 15 * 60 * 1000,
    delayAfter: 50,
    delayMs: (used) => (used - 50) * 100,
    maxDelayMs: 5000,
  }));

  // ── 9. Global rate limiter ───────────────────────────────────────────
  app.use(RateLimiterFactory.createGlobalLimiter());

  // ── 10. Compression ──────────────────────────────────────────────────
  app.use(compression());

  // ── 11. Health check (no auth, no rate limit) ────────────────────────
  app.get('/health', (req, res) => {
    res.status(200).json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: process.uptime()
    });
  });

  // ── 12. API routes ───────────────────────────────────────────────────
  app.use('/api/v1/auth',          RateLimiterFactory.createAuthLimiter(), authRouter);
  app.use('/api/v1/users',         authenticate, usersRouter);
  app.use('/api/v1/habits',        authenticate, habitsRouter);
  app.use('/api/v1/goals',         authenticate, goalsRouter);
  app.use('/api/v1/journal',       authenticate, journalRouter);
  app.use('/api/v1/mood',          authenticate, moodRouter);
  app.use('/api/v1/sleep',         authenticate, sleepRouter);
  app.use('/api/v1/nutrition',     authenticate, nutritionRouter);
  app.use('/api/v1/finance',       authenticate, financeRouter);
  app.use('/api/v1/ai',            authenticate, RateLimiterFactory.createAILimiter(), aiRouter);
  app.use('/api/v1/notifications', authenticate, notificationsRouter);
  app.use('/api/v1/achievements',  authenticate, achievementsRouter);
  app.use('/api/v1/subscriptions', authenticate, subscriptionsRouter);

  // ── 13. 404 handler ──────────────────────────────────────────────────
  app.use((req: Request, res: Response) => {
    throw new NotFoundError(`Route ${req.method} ${req.path} not found`);
  });

  // ── 14. Global error handler (MUST be last) ──────────────────────────
  app.use(globalErrorHandler);

  return app;
}
```

---

### ADDITIONAL SECURITY PACKAGES — ADD TO `package.json`

```json
{
  "dependencies": {
    "express-mongo-sanitize": "^2.2.0",
    "xss-clean": "^0.1.4",
    "hpp": "^0.2.3",
    "express-slow-down": "^2.0.1",
    "compression": "^1.7.4",
    "safe-regex": "^2.1.1"
  },
  "devDependencies": {
    "@types/hpp": "^0.2.6",
    "@types/compression": "^1.7.5",
    "@types/safe-regex": "^1.1.3"
  }
}
```

---

### SECURITY QUALITY CHECKLIST — ALL MUST PASS

Add these to the build order as step 0 (before everything else):

```
AUTHENTICATION
- [ ] JWT access tokens expire in 15 minutes maximum
- [ ] Refresh tokens are hashed (SHA-256) before storing in MongoDB
- [ ] Refresh token rotation on every refresh call — old token immediately invalid
- [ ] Refresh token reuse detection — all sessions revoked on suspicious reuse
- [ ] bcrypt cost factor 12 for password hashing
- [ ] Same error message for "user not found" and "wrong password" (prevents user enumeration)
- [ ] Rate limit: 10 auth attempts per 15 minutes per IP
- [ ] Account lockout after 10 failures (Redis-backed, 30 minute cooldown)

AUTHORISATION
- [ ] Every repository query that returns user-owned data scoped to req.user.id
- [ ] Unauthorised resource access returns 404 not 403 (prevents existence leakage)
- [ ] Role check middleware applied to all admin routes
- [ ] No route exposes another user's data under any circumstance

INPUT VALIDATION
- [ ] Every request body parsed through a Zod schema with .strict()
- [ ] All string fields have .max() length limits
- [ ] All ID params validated as MongoDB ObjectId before use
- [ ] express-mongo-sanitize removes $ and . operator keys
- [ ] xss-clean sanitises all string inputs
- [ ] hpp prevents parameter pollution

HEADERS & TRANSPORT
- [ ] Helmet sets all security headers including CSP
- [ ] HTTPS enforced via HSTS header (maxAge: 31536000)
- [ ] X-Powered-By header removed
- [ ] CORS whitelist to only known origins
- [ ] Request body size limited to 10kb

INJECTION PREVENTION
- [ ] No user input ever passed directly to a Mongoose query
- [ ] All MongoDB queries use typed parameters from validated DTOs
- [ ] No eval(), no Function(), no child_process with user input
- [ ] No user-supplied regex used in application code

DATA PROTECTION
- [ ] passwordHash excluded with .select('-passwordHash') on all user queries
- [ ] No sensitive data in JWT payload beyond userId, email, role, tier
- [ ] No sensitive data in logs (no passwords, no raw tokens, no full JWTs)
- [ ] All tokens in logs shown as first 8 chars + '...' only

DDOS PROTECTION
- [ ] Global rate limit: 100 req/min per IP
- [ ] Auth rate limit: 10 req/15min per IP
- [ ] AI rate limit: 20 req/min per user
- [ ] Speed limiter adds delay after 50 req/15min
- [ ] Cloudflare Workers gateway as first line of defence
- [ ] Body size limit: 10kb

LOGGING & MONITORING
- [ ] SecurityLogger.logEvent() called on every auth failure
- [ ] SecurityLogger.logEvent() called on every rate limit breach
- [ ] SecurityLogger.logEvent() called on CORS violation
- [ ] SecurityLogger.logEvent() called on NoSQL injection attempt
- [ ] Critical security events logged at ERROR level for BetterStack alerting
- [ ] Every log line includes: requestId, ip, userId, timestamp
- [ ] No stack traces in production API responses
```

---

### SECURITY TESTS — WRITE THESE

Create `tests/security/` directory with these test files:

**`tests/security/auth.security.test.ts`**
- Brute force: 11 consecutive failed logins → 429 on 11th
- User enumeration: same error message for unknown email vs wrong password
- JWT tampering: modified token signature → 401
- Expired token: wait for expiry → 401
- Refresh token reuse: use a refresh token twice → second use revokes all sessions

**`tests/security/injection.security.test.ts`**
- NoSQL injection in login body: `{ "email": { "$gt": "" } }` → 400 ValidationError
- XSS in habit name: `<script>alert(1)</script>` → stored as sanitised string
- HPP: duplicate query params → only first value used

**`tests/security/authorisation.security.test.ts`**
- IDOR: user A requests user B's habit by ID → 404 (not 200, not 403)
- Mass assignment: send `role: admin` in profile update → role unchanged
- Mass assignment: send `tier: premium` in profile update → tier unchanged

**`tests/security/headers.security.test.ts`**
- All Helmet headers present in every response
- X-Powered-By absent from all responses
- CORS: disallowed origin → 403
- Body too large: 11kb JSON body → 413
