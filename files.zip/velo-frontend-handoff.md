# VELO FRONTEND — CLAUDE CODE HANDOFF PROMPT
# Paste this as your FIRST message in a new Claude Code session on your personal machine
# This is a continuation of an existing Angular project being migrated from Google Sheets to Node.js backend

---

## WHO YOU ARE

You are a senior Angular engineer continuing work on the Velo Life Tracker frontend. This project was a working Angular app using Google Apps Script + Google Sheets as its backend. That backend is now being replaced with a Node.js API. You are migrating ALL data calls, adding new screens, and building the freemium/AI companion system.

Read this entire prompt before writing a single line of code.

---

## WHAT VELO IS

Velo Life Tracker is a personal life-tracking Progressive Web App + Android app (Capacitor). Features: habits, goals, journal, mood, sleep, nutrition, finance, Pomodoro timer, AI companion.

Business model: freemium. Free tier hooks users with limited features. Premium tier (£44.99/year or £7.99/month) unlocks advanced features and AI companion. Conversion happens through emotional moments, not paywalls at login.

---

## TECH STACK

- Angular 17+ with standalone components throughout
- Angular Signals for all reactive state
- Angular Router with lazy loading per feature
- TypeScript strict mode — zero `any` types
- Angular Animations for transitions
- Capacitor 5+ for Android
- @capacitor/push-notifications for FCM
- Angular PWA (service worker, offline support)
- Tailwind CSS (already installed) or Angular Material (check what's already in the project)

---

## BACKEND API

The new backend runs at:
- Development: `http://localhost:3000/api/v1`
- Production: `https://velo-backend-xxxx.onrender.com/api/v1` (you will update this after Render deploy)

Update `src/environments/environment.ts`:
```typescript
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api/v1',
  appName: 'Velo'
};
```

Update `src/environments/environment.prod.ts`:
```typescript
export const environment = {
  production: true,
  apiUrl: 'https://YOUR_RENDER_URL.onrender.com/api/v1',
  appName: 'Velo'
};
```

---

## WHAT ALREADY EXISTS (DO NOT REWRITE)

The app has existing Angular components for all the tracking features (habits, goals, journal, mood, sleep, nutrition, Pomodoro, finance). These components currently call Google Apps Script endpoints.

Your job is NOT to rebuild these components from scratch. Your job is:
1. Replace all Google Apps Script / Google Sheets service calls with new API service calls
2. Add the new screens listed below (onboarding, AI companion, freemium dashboard, discover page)
3. Add Capacitor Android + push notification integration
4. Add the auth system (register/login pages + guards)

First task when you start: `find . -name "*.service.ts" | head -20` to see what services exist and what they currently call.

---

## CORE SERVICES TO CREATE OR REPLACE

### ApiService (src/app/core/services/api.service.ts)
```typescript
// Base HTTP service. All other services use this.
// Auto-attaches Authorization: Bearer {token} header
// On 401 → calls AuthService.refreshToken() → retries once → if still 401 → logout
// On 403 with code UPGRADE_REQUIRED → triggers UpgradeModalService.open()
```

### AuthService (src/app/core/services/auth.service.ts)
```typescript
// login(email, password) → POST /auth/login → store tokens in localStorage
// register(name, email, password) → POST /auth/register
// logout() → POST /auth/logout → clear localStorage → navigate /login
// refreshToken() → POST /auth/refresh → update stored tokens
// isAuthenticated(): boolean → check if valid token exists
// currentUser: signal<User | null>
```

### VeloAiService (src/app/core/services/velo-ai.service.ts)
```typescript
// getDashboard() → GET /ai/dashboard
// getDailyCheckin() → GET /ai/checkin
// getWeeklyReport() → GET /ai/weekly-report
// getFeatureImpact(featureId) → GET /ai/feature-impact/:featureId
// getConversionPitch() → POST /ai/conversion-pitch
// All responses cached in localStorage with timestamp
// Cache TTLs: dashboard 30d, checkin 23h, weekly 6d, feature-impact 7d
```

### UserService (src/app/core/services/user.service.ts)
```typescript
// getProfile() → GET /users/profile
// updateProfile(data) → PATCH /users/profile
// saveOnboarding(data) → POST /users/onboarding
// registerDeviceToken(token) → POST /users/device-token
```

### Each feature module gets its own service:
```
HabitService   → calls /habits/* 
GoalService    → calls /goals/*
JournalService → calls /journal/*
MoodService    → calls /mood/*
SleepService   → calls /sleep/*
NutritionService → calls /nutrition/*
FinanceService → calls /finance/*
```

Replace all Google Sheets calls in existing components with these new services.

---

## NEW SCREENS TO BUILD

### 1. Auth Pages (/login, /register)
Clean, minimal. Email + password. On /register: name, email, password, confirm password.
After register → redirect to /onboarding.
After login → if onboardingCompleted → /dashboard, else → /onboarding.
Guards: `AuthGuard` (requires login), `GuestGuard` (redirects logged-in users away from /login).

### 2. Onboarding Wizard (/onboarding) — 5 steps, full screen, no app shell

**Step 1 — The Why**
Free text: "What's the main reason you're here? What do you want to change?"
Claude responds empathetically (call /ai/... or use pre-written responses for speed).
Follow-up: "How long have you been working on this?" → Just starting / A few months / Over a year
Store: `primaryGoal`, `experienceLevel`

**Step 2 — Commitment**
"How much time can you give each day?"
Options: 5–10 min · 15–30 min · 30–60 min
Store: `dailyCommitmentMinutes`

**Step 3 — Features Grid**
Visual grid of all 10 Velo features as cards (icon + name + one-line description).
Show ALL features. Mark premium ones with a ⭐ icon but no text saying "premium" yet.
User selects 1–8. Store: `selectedFeatures[]`

Features to show:
- habits "Build streaks for daily non-negotiables"
- goals "Break big goals into weekly targets"
- journal "Reflect and process your days"
- mood "Spot emotional patterns over time"
- sleep "Understand your rest and energy patterns"
- nutrition "Track meals and hit your macros"
- finance "Save smarter, spend intentionally" ⭐
- pomodoro "Stay focused with timed work sessions"
- ai_checkin "Your daily AI companion check-in" ⭐
- achievements "Earn XP, badges, and level up"

**Step 4 — Lifestyle**
"When do you usually check in with yourself?" → Morning / Midday / Evening / Varies
"What motivates you most?" → Seeing streaks grow / Hitting big milestones / Feeling daily progress / Accountability
Store: `checkinTime`, `motivationStyle`

**Step 5 — Companion Personality**
"How do you want your AI companion to talk to you?"
4 options with emoji + 1-line description:
🏋️ Coach — Direct, no-nonsense, holds you accountable
😊 Friend — Warm, encouraging, celebrates everything
📊 Analyst — Data-driven, gives insights and patterns
🧘 Sage — Calm, reflective, helps you stay grounded
Store: `companionStyle`

After step 5:
- Show 2-second animated loading screen: "Building your personal Velo dashboard..."
- Call POST /users/onboarding with all collected data
- Call GET /ai/dashboard (backend generates personalized config)
- Navigate to /dashboard

Progress bar at top showing steps 1–5. Animate transitions: slide in from right.

### 3. Dynamic Dashboard (/dashboard)

Layout driven by AI dashboard config from /ai/dashboard.

Top section:
- Personalized greeting from AI companion
- "Your 90-day transformation" card — full width, shows `career_impact_message`
- Today's first challenge card

Feature widgets below, ordered by priority from AI config:
- Free features: fully interactive
- Premium features user selected during onboarding: show blurred preview + frosted glass overlay
- Overlay text: "Unlock with Velo Premium" + "See what you're missing" button (opens upgrade modal)
- Features NOT selected during onboarding: not shown at all

Premium horizon section at bottom:
- "Ready to go further?" section
- Shows 2–3 premium features NOT yet selected, with AI-generated impact sentence for each
- Each has "Add to dashboard" button

### 4. AI Companion Panel (floating, every page)

Floating circle button bottom-right (56px, Velo logo/icon). Always visible when logged in.

On first open each day → shows daily check-in from /ai/checkin:
- Opening message
- Progress highlight
- Today's focus
- One concrete challenge
- Streak status

Other days → shows last cached check-in + "View weekly report" if Sunday.

Panel also contains:
- Explore more features → /discover
- Your achievements → /achievements
- Settings → /settings

### 5. Discover Page (/discover)

For each feature NOT on the user's dashboard:
- Feature icon + name
- AI-generated "How this changes your life" paragraph (GET /ai/feature-impact/:featureId)
- Add to dashboard button (calls API → gets new dashboard config → updates dashboard)

### 6. Upgrade Modal (component, triggered anywhere)

Shown when:
- User taps a premium-blurred feature
- Conversion trigger fires (7-day streak, 30-day milestone, etc.)
- API returns 403 with UPGRADE_REQUIRED

Content (personalized by AI companion):
- Headline referencing user's primary goal
- 3 specific benefits for their goal
- Pricing: Annual £44.99/yr (most popular, show first) · Monthly £7.99/mo
- CTA: "Start my transformation" (not "Upgrade" or "Buy")
- [BILLING_WIRE_HERE] comment — billing not implemented yet, button shows "Coming soon" toast

Tone rules — NEVER use these words: "sorry", "unfortunately", "upgrade" (as verb), "blocked", "locked", "buy now", "premium only".

### 7. Achievements Page (/achievements)

- XP bar showing current level (Rookie/Builder/Achiever/Champion)
- Badge grid — earned badges full colour, unearned greyed out
- Current streaks per feature
- When badge earned → full-screen celebration modal with canvas-confetti

XP system:
- +10 per feature log
- +25 per daily check-in completed
- +50 per 7-day streak
- +100 per goal hit
- +200 per 30-day streak
Levels: Rookie 0–500 · Builder 500–1500 · Achiever 1500–3500 · Champion 3500+

---

## CONVERSION TRIGGERS — FIRES ONCE PER LIFETIME PER USER

Build a `ConversionTriggerService` that tracks which triggers have fired in localStorage.
Each trigger fires at most once per user lifetime, with max 1 per day.

```
day3_insight_teaser     → Day 3: show "Here's what premium users are seeing about their progress..."
streak_7_milestone      → 7-day streak: celebration + show premium benefits
free_limit_reached      → When user hits free tier limit on a module
premium_feature_touch   → First time user taps a blurred premium feature
weekly_report_tease     → After first week: show preview of premium weekly report
goal_progress_plateau   → When goal progress slows: "Unlock AI coaching to break through"
day30_milestone         → Day 30 active: "You've been consistent — ready to go deeper?"
```

Each trigger → opens UpgradeModal with context-appropriate content.

---

## CAPACITOR ANDROID SETUP

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npm install @capacitor/push-notifications
npx cap init "Velo" "com.velo.app"
ng build --configuration production
npx cap add android
npx cap sync
```

capacitor.config.ts:
```typescript
const config: CapacitorConfig = {
  appId: 'com.velo.app',
  appName: 'Velo',
  webDir: 'dist/velo-frontend/browser',
  plugins: {
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert']
    }
  }
};
```

PushNotificationService:
- On app init: request permission, get FCM token
- Send token to POST /users/device-token
- Handle token refresh → re-send to API
- Handle foreground notifications → show in-app toast
- Handle tap on notification → navigate to relevant route

---

## ROUTING STRUCTURE

```typescript
const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'login', loadComponent: () => import('./features/auth/login.component'), canActivate: [GuestGuard] },
  { path: 'register', loadComponent: () => import('./features/auth/register.component'), canActivate: [GuestGuard] },
  { path: 'onboarding', loadComponent: () => import('./features/onboarding/onboarding.component'), canActivate: [AuthGuard] },
  {
    path: '',
    component: AppShellComponent,  ← contains nav + floating companion button
    canActivate: [AuthGuard],
    children: [
      { path: 'dashboard', loadComponent: () => import('./features/dashboard/dashboard.component') },
      { path: 'habits', loadComponent: () => import('./features/habits/habits.component') },
      { path: 'goals', loadComponent: () => import('./features/goals/goals.component') },
      { path: 'journal', loadComponent: () => import('./features/journal/journal.component') },
      { path: 'mood', loadComponent: () => import('./features/mood/mood.component') },
      { path: 'sleep', loadComponent: () => import('./features/sleep/sleep.component') },
      { path: 'nutrition', loadComponent: () => import('./features/nutrition/nutrition.component') },
      { path: 'finance', loadComponent: () => import('./features/finance/finance.component') },
      { path: 'pomodoro', loadComponent: () => import('./features/pomodoro/pomodoro.component') },
      { path: 'discover', loadComponent: () => import('./features/discover/discover.component') },
      { path: 'achievements', loadComponent: () => import('./features/achievements/achievements.component') },
      { path: 'settings', loadComponent: () => import('./features/settings/settings.component') },
    ]
  }
];
```

---

## HTTP INTERCEPTOR — AUTO AUTH HEADERS

```typescript
// src/app/core/interceptors/auth.interceptor.ts
// Attaches Bearer token to every request automatically
// On 401 → try refresh → if refreshed, retry original request
// If refresh fails → logout → navigate /login
// On 403 UPGRADE_REQUIRED → open upgrade modal
```

---

## BUILD ORDER

1. Check existing file structure: `find src -name "*.ts" | head -40`
2. Check existing services: read every *.service.ts to understand current data calls
3. Update environment.ts files with new API URLs
4. Create core/services/api.service.ts (base HTTP)
5. Create core/services/auth.service.ts
6. Create core/interceptors/auth.interceptor.ts
7. Create core/guards/auth.guard.ts + guest.guard.ts
8. Create login + register pages
9. Replace ALL Google Apps Script calls in existing services with new API calls
10. Create VeloAiService
11. Create UserService
12. Build onboarding wizard (5 steps)
13. Build dynamic dashboard
14. Build floating companion panel component
15. Build upgrade modal component + ConversionTriggerService
16. Build discover page
17. Build achievements page
18. Capacitor Android setup
19. PushNotificationService + FCM integration
20. Test on Android device

After step 2 (reading existing code), STOP. Tell me what Google Apps Script calls you found and confirm the migration plan before changing anything.

After step 9 (replacing Google Sheets calls), STOP. I will test that existing features still work with the new backend before building new screens.

---

## START COMMAND

After reading this entire prompt, begin with:
"Starting by reading the existing codebase. Running find commands to understand the current structure."

List everything you find, then pause and tell me what Google Apps Script / Sheets calls exist and what the migration plan is.
